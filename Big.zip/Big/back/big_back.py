from flask import Flask,render_template,jsonify,request
import flask_cors
import json

app = Flask(__name__) # 创建一个Flask对象，__name__传成其他字符串也行。
flask_cors.CORS(app, supports_credentials=True)

@app.route('/bio/name',methods=['GET'])

def bio():# 生物多样性
    with open("./json/bio/bio.json",'r') as bio_num:
       bio = json.load(bio_num)
       
    with open("./json/bio/bioPoint.json",'r') as bio_point:
        bioPoint = json.load(bio_point)
    
    with open("./json/bio/bioIntroduction.json",'r') as bio_introduction:
        bioIntroduction = json.load(bio_introduction)[0]
      
    return jsonify({'code':'0','bio':bio,'bioPoint':bioPoint,'bioIntroduction':bioIntroduction,'msg':'ok'})

@app.route('/ques/name',methods=['GET'])

def ques():# 监管督办
    total = 0
    
    with open("./json/ques/quesPoint.json",'r') as question_points:
        quesPoint = json.load(question_points)
    
    with open("./json/ques/quesInfo.json",'r') as question_information:
        quesInfo = json.load(question_information)
    
    for points in quesPoint:
        if points['state'] == "treating":
            total += points['value']
    
    return jsonify({'code':'0', 'total':total, 'quesPoint':quesPoint,'quesInfo':quesInfo,'msg':'ok'})

@app.route('/equip/name',methods=['GET'])

def equip():# 设备管理

    with open("./json/equip/equipInfo.json",'r') as equipment_information:
        equip = json.load(equipment_information)
    
    with open("./json/equip/equipPoint.json",'r') as equipment_points:
        equipPoint = json.load(equipment_points)
    

    return jsonify({'code':'0', 'equip':equip,'equipPoint':equipPoint,'msg':'ok'})

if __name__ == '__main__':

    app.run(host='127.0.0.1',port=8060)
    