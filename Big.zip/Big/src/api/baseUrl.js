// 根据域名来决定接口地址
/* const url = window.location.protocol+"//"+window.location.host */
// 是否为生产环境
const isProductionEnv = process.env.NODE_ENV === 'production'
let baseURLHttp
if (!isProductionEnv) {
  baseURLHttp = 'http://127.0.0.1:8060' // 开发地址
  console.log('开发地址')
} else {
  baseURLHttp = 'http://36.152.8.235:8090' // 生产地址
  console.log('生产地址')
}
// 开发环境调用接口
export default baseURLHttp
