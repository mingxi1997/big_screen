// 调用接口 方便管理
import request from './request'
import qs from 'qs'
export default {
  // 用于请求token
  getToken (obj) {
    return request({
      url: '/api/getToken',
      method: 'GET',
      params: obj
    })
  },
  // 用于请求 环境因子
  getRealTimeDataByDeviceAddr (obj) {
    return request({
      url: 'http://36.152.8.235:8090/env_data',
      method: 'GET',
      params: obj
    })
  },
  // 用于请求 环境因子
  getRealTimeData (obj) {
    return request({
      url: '/api/data/getRealTimeData',
      method: 'GET',
      params: obj
    })
  }
}
