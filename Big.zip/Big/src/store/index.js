import { createStore } from 'vuex'
import home from './home'
export default createStore({
  modules: {
    home
  }
})
