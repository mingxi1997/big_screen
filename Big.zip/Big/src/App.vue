<template>
  <div id="nav">
    <Nav/>
  </div>
  <router-view/>
</template>

<script>
import Nav from '@/components/Nav.vue'
import http from '@/api/template'
import { ElMessage } from 'element-plus'

export default {
  name: 'App',
  components: { Nav },
  props: [],
  emits: [],
  setup (props, context) {
    // http.getToken({
    //   loginName: 'h220227swdy',
    //   password: 'h220227swdy'
    // }).then(res => {
    //   if (res.code === 1000 && res.data && res.data.token) {
    //     localStorage.setItem('ISTOKEN', res.data.token)
    //   } else {
    //     ElMessage.error('获取登录态失败')
    //   }
    // }).catch(err => {
    //   console.log(err)
    // })
    return {}
  }
}
</script>

<style lang="less">
::-webkit-scrollbar {  /* 滚动条整体部分 */
  width:0px;
  margin-right:2px
}
::-webkit-scrollbar-button { /* 滚动条两端的按钮 */
  width:0px;
  background-color: yellow;
}
::-webkit-scrollbar:horizontal {
  height:0px;
  margin-bottom:2px
}
::-webkit-scrollbar-track {  /* 外层轨道 */
  border-radius: 0px;
}
::-webkit-scrollbar-track-piece {  /*内层轨道，滚动条中间部分 */
  background-color: #333333;
  border-radius: 10px;
}
::-webkit-scrollbar-thumb {  /* 滑块 */
  width:0px;
  border-radius: 5px;
  background: #CBCBCB;
}
::-webkit-scrollbar-corner { /* 边角 */
  width: 10px;
  background-color: red;
}
::-webkit-scrollbar-thumb:hover { /* 鼠标移入滑块 */
  background: #909090;
}
#app {
  font-family: Microsoft YaHei;
  background: url('./assets/bj.png') no-repeat;
  background-size: 100% 100%;
  color: white;
  width: 3840px;
  height: 2080px;
  // font-size: 1vw;
}

</style>
