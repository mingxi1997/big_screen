<template>
  <div>
    <el-dialog v-model="dialogVisible" title="种类趋势" :show-close="false">
      <div class="btn_exit">
        <img
          src="../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="width: 0.13rem; float: right; margin-top: -0.23rem; cursor:pointer;"
        />
      </div>
      <div>
        <img
          src="../../../common/picture/xiaotiane.jpg"
          alt=""
          style="width: 4.9rem; margin-top: 0"
        />
      </div>
      <div style="margin-top: 0.03rem; margin-left: 0.4rem; text-align: center">
        <span id="Type_name" style="font-fanily: 'FZMWFont'">8月</span>
        <div style="float: right; margin-right: 0.2rem">
          数量：<span id="Type_number">120</span> 只
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
  <div class="typeBox">
    <div id="mytype" style="width: 100%; height: 100%" v-if="isShowEcharts"></div>
  </div>
</template>

<script>
import * as echarts from "echarts";
import {  ref, onUnmounted } from "vue";

export default {
  name: "Type",
  data() {
    const dialogVisible = ref(false);
    return { dialogVisible };
  },
  setup(props, context) {
    const mytype = ref(null);
    const value = ref("");
    let isShowEcharts = ref(true);
    const options = [
      {
        value: "1",
        label: "小天鹅",
      },
      {
        value: "2",
        label: "白鹭",
      },
      {
        value: "3",
        label: "绿头潜鸭",
      },
      {
        value: "4",
        label: "大雁",
      },
      {
        value: "5",
        label: "白骨顶",
      },
    ];
    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    const option = ref({});
    return { option, value, options, isShowEcharts };
  },
  mounted() {
    var myChart = echarts.init(document.getElementById("mytype"));
    var option = {
      backgroundColor: "transparent",
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow",
        },
        // formatter: '{a} <br/>{b} : {c} ({d}%)'
      },
      grid: {
        left: "0",
        right: "10%",
        bottom: "10%",
        top: "8%",
        containLabel: true,
      },
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          data: ["8月", "9月", "10月", "11月", "12月", "1月", "2月", "3月"],
          axisLabel: {
            fontSize: "0.06rem",
            color: "#fff",
          },
        },
      ],
      yAxis: [
        {
          type: "value",
          axisLabel: {
            fontSize: "0.06rem",
            color: "#fff",
          },
        },
      ],
      series: [
        {
          name: "数量",
          type: "line",
          smooth: true,
          // stack: 'Total',
          itemStyle: {
            color: "rgb(255, 225, 255)",
            borderColor: "rgb(220, 225, 255)",
            borderWidth: 5,
            shadowColor: "white",
            shadowBlur: 10,
          },
          lineStyle: {
            color: "rgba(43, 220, 234, 0.6)",
          },
          areaStyle: {
            color: {
              type: "linear",
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                {
                  offset: 0,
                  color: "rgba(30, 212, 255, 0.6)", // 0% 处的颜色
                },
                {
                  offset: 0.5,
                  color: "rgba(28, 175, 250, 0.3)", // 0% 处的颜色
                },
                {
                  offset: 1,
                  color: "transparent", // 100% 处的颜色
                },
              ],
              global: false, // 缺省为 false
            },
          },
          emphasis: {
            focus: "series",
          },
          data: [120, 132, 101, 134, 90, 230, 210, 150],
        },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
    // myChart.on("click", function (params) {
    //   // 在用户点击后控制台打印数据的名称
    //   console.log(params);
    // });
    // myChart.on("click", this.nav_open);
    // myChart.on("click", function (param) {
    //   // console.log(param.name);
    //   const typeName = param.name;
    //   const typeNumber = param.value;
    //   // console.log(BirdName);
    //   document.getElementById("Type_name").innerHTML = typeName;
    //   document.getElementById("Type_number").innerHTML = typeNumber;
    // });
  },
  methods: {
    nav_open() {
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
.typeBox {
  width: 100%;
  height: 100%;
}
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.8rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
</style>
