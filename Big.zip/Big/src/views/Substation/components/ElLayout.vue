<template>
  <div>
    <el-dialog v-model="dialogVisible" title="实时数量监测页面">
      <div>
        <img
          src="../../../common/picture/xiaotiane.jpg"
          alt=""
          style="width: 4.9rem"
        />
      </div>
      <div>小天鹅的数量是——15只</div>
      <div id="Bir_name">{{ birdName }}</div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">关闭</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ElForm } from 'element-plus'
import 'element-plus/es/components/layout/style/css'

export default {
    name: 'ElLayout',
    props: {
        birdName: String
    }
}
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.8rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
}
</style>