<template>
  <div class="environmentBox">
    <div class="environment-item" v-for="(item, index) in list" :key="index">
      <div class="environment-text">
        {{ parseInt(item.registerItem.value) + item.registerItem.unit }}
      </div>
      <div class="environment-title">{{ item.title }}</div>
    </div>
  </div>
</template>

<script>
import http from "@/api/template";
import { ref } from "vue";

export default {
  name: "Environment",
  components: {},
  props: [],
  emits: [],
  setup() {
    const list = ref([]);
    http
      .getRealTimeDataByDeviceAddr()
      .then((res) => {
        res.data[0].dataItem.forEach((item) => {
          if (item.nodeId === 1) {
            list.value.push({
              title: "风速",
              registerItem: item.registerItem[1],
            });
          } else if (item.nodeId === 2) {
            list.value.push({
              title: "风向",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 6) {
            list.value.push({
              title: "紫外线",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 8) {
            list.value.push({
              title: "空气温度",
              registerItem: item.registerItem[0],
            });
            list.value.push({
              title: "空气湿度",
              registerItem: item.registerItem[1],
            });
          } else if (item.nodeId === 9) {
            list.value.push({
              title: "噪声",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 10) {
            list.value.push({
              title: "PM2.5",
              registerItem: item.registerItem[0],
            });
            list.value.push({
              title: "PM10",
              registerItem: item.registerItem[1],
            });
          } else if (item.nodeId === 11) {
            list.value.push({
              title: "大气压力",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 12) {
            list.value.push({
              title: "光照",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 13) {
            // 雨量
            list.value.push({
              title: "雨量",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 14) {
            list.value.push({
              title: "二氧化碳",
              registerItem: item.registerItem[0],
            });
          } else if (item.nodeId === 26) {
            list.value.push({
              title: "水温",
              registerItem: item.registerItem[0],
            });
            list.value.push({
              title: "水质ph",
              registerItem: item.registerItem[1],
            });
          } else if (item.nodeId === 27) {
            list.value.push({
              title: "ORP",
              registerItem: item.registerItem[0],
            });
          }
        });
      })
      .catch((err) => {
        list.value = [
          {
            title: "大气温度",
            registerItem: {
              unit: "℃",
              value: "26",
            },
          },
          {
            title: "大气湿度",
            registerItem: {
              unit: "hPa",
              value: "50",
            },
          },
          {
            title: "光照",
            registerItem: {
              unit: "Lux",
              value: "20",
            },
          },
          {
            title: "大气压力",
            registerItem: {
              unit: "kpa",
              value: "101.3",
            },
          },
          {
            title: "噪声",
            registerItem: {
              unit: "dB",
              value: "30",
            },
          },
          {
            title: "PM2.5",
            registerItem: {
              unit: "μg/m³",
              value: "80",
            },
          },
          {
            title: "PM10",
            registerItem: {
              unit: "μg/m³",
              value: "10",
            },
          },
          {
            title: "二氧化碳",
            registerItem: {
              unit: "ppm",
              value: "664",
            },
          },
          {
            title: "风速",
            registerItem: {
              unit: "m/s",
              value: "31",
            },
          },
          {
            title: " 风向",
            registerItem: {
              unit: "",
              value: "偏南风",
            },
          },
          {
            title: "雨量",
            registerItem: {
              unit: "mm/h",
              value: "200",
            },
          },
          {
            title: "紫外线",
            registerItem: {
              unit: "W/m",
              value: "10",
            },
          },
          {
            title: "水质PH",
            registerItem: {
              unit: "mg/L",
              value: "0.3",
            },
          },
          {
            title: "水温",
            registerItem: {
              unit: "℃",
              value: "22",
            },
          },
          {
            title: "ORP",
            registerItem: {
              unit: "mV",
              value: "150",
            },
          },
        ];
      });
    return { list };
  },
};
</script>

<style lang="less" scoped>
.environmentBox {
  width: 100%;
  height: 645px;
  padding-top: 50px;
  box-sizing: border-box;
  .environment-item {
    width: 153px;
    height: 93px;
    margin-right: 15px;
    margin-bottom: 57px;
    background: url("../../../assets/home/btnbg.png") no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    vertical-align: top;
    .environment-text {
      width: 100%;
      height: 55px;
      line-height: 75px;
      font-size: 0.078rem;
      color: #ffe175;
      text-align: center;
    }
    .environment-title {
      width: 100%;
      font-size: 0.06rem;
      font-family: Microsoft YaHei;
      font-weight: 400;
      text-align: center;
    }
  }
}
</style>
