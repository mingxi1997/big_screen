<template>
  <div class="mapBox">
    <div class="lefttop"></div>
    <div class="leftbottom"></div>
    <div class="righttop"></div>
    <div class="rightbottom"></div>
    <div
      class="container"
      id="container1"
      style="height: 100%; background: transparent !important"
    ></div>
    <!--    <div class="info">-->
    <!--      <div class="info-title">江苏省环保厅</div>-->
    <!--      <div class="info-icon1">已建成站点</div>-->
    <!--      <div class="info-icon2">未建成站点</div>-->
    <!--    </div>-->
    <div class="title">
      <el-button @click="doHome">返回</el-button>
      <img src="../../../assets/back_home.png" alt="" @click="doHome" style="width: 0.06rem; float: right; margin-top: -0.23rem; cursor:pointer;">
    </div>
  </div>
  <el-dialog v-model="dialogVisible" title="预览">
    <!--    autoplay-->
    <video
      ref="videoRef"
      class="video"
      src="../../../common/video/yan.7f04c582.mp4"
    ></video>
    <div class="yuntai">
      <div class="top">上</div>
      <div class="left">左</div>
      <div class="content" @click="play">播放</div>
      <div class="right">右</div>
      <div class="bottom">下</div>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogVisible = false">关闭</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script>
import map from "@/utils/map";
import { useRouter } from "vue-router";
import { onUnmounted, ref, watch } from "vue";
export default {
  name: "Map",
  components: {},
  props: [],
  emits: [],
  setup(props, context) {
    const router = useRouter();
    const dialogVisible = ref(false);
    let mymap = null;
    let myAMap = null;
    let infoWindow = null;
    const info = ref(null);
    const doHome = () => {
      router.push("/");
    };
    map.mapUI("70f795a63de3e135ddaf4b1a637f33a5").then((AMap) => {
      myAMap = AMap;
      mymap = new AMap.Map("container1", {
        zoom: 11, // 级别
        mapStyle: "amap://styles/grey",
      });
      infoWindow = new AMap.InfoWindow({
        // isCustomElement:
        isCustom: true,
        offset: new AMap.Pixel(0, -30),
      });
      const infoWindowClose = () => {
        infoWindow.close();
      };
      mymap.on("complete", () => {
        [
          {
            id: 1,
            position: [118.642683, 31.956352],
          },
          {
            id: 2,
            position: [118.672908, 31.996092],
          },
          {
            id: 3,
            position: [118.731847, 32.085125],
          },
        ].forEach((d) => {
          const marker = new myAMap.Marker({
            position: d.position,
            offset: new myAMap.Pixel(-8, -30),
            icon: require("../../../assets/substation/camera.png"),
            map: mymap,
          });
          
          marker.d = d;
          marker.content = `<div style="font-size: 24px;color: #fa9600;background-color: rgba(255,255,255,0.5);">南京检测点：${d.id}号点</div>`;
          marker.on("mouseover", markerClick);
          marker.on("click", myVideo);
          // marker.on('mouseout', infoWindowClose)
          marker.emit("mouseover", { target: marker });
        });
        mymap.setFitView(null, false, [100, 100, 100, 100]);
      });
    });
    const markerClick = (e) => {
      info.value = e.target.d;
      infoWindow.setContent(e.target.content);
      infoWindow.open(mymap, e.target.getPosition());
    };
    const myVideo = (e) => {
      info.value = e.target.d;
      console.log(213);
      dialogVisible.value = true;
    };
    const videoRef = ref(null);
    watch(dialogVisible, (newValue) => {
      // paused
      if (!newValue) {
        // console.log(videoRef.value)
        videoRef.value.pause();
      }
    });
    const play = () => {
      console.log(videoRef.value.play);
      videoRef.value.play();
    };
    onUnmounted(() => {
      mymap.destroy();
    });
    return {
      videoRef,
      play,
      dialogVisible,
      doHome,
    };
  },
};
</script>

<style lang="less" scoped>
.mapBox {
  position: relative;
  height: 1110px;
  padding: 10px 129px 78px 129px;
  box-sizing: border-box;
  .lefttop,
  .leftbottom,
  .righttop,
  .rightbottom {
    position: absolute;
    width: 67px;
    height: 62px;
  }
  .lefttop {
    top: 0;
    left: 119px;
    border-top: 2px solid #20dbfd;
    border-left: 2px solid #20dbfd;
  }
  .leftbottom {
    left: 119px;
    bottom: 68px;
    border-left: 2px solid #20dbfd;
    border-bottom: 2px solid #20dbfd;
  }
  .righttop {
    top: 0;
    right: 119px;
    border-top: 2px solid #20dbfd;
    border-right: 2px solid #20dbfd;
  }
  .rightbottom {
    right: 119px;
    bottom: 68px;
    border-right: 2px solid #20dbfd;
    border-bottom: 2px solid #20dbfd;
  }
  .title {
    position: absolute;
    right: 170px;
    top: 90px;
    font-size: 35px;
    font-weight: 400;
    text-align: right;
  }
  .info {
    position: absolute;
    left: 208px;
    bottom: 126px;
    width: 236px;
    height: 223px;
    background: url("../../../assets/home/kuag.png") no-repeat;
    background-size: 100% 100%;
    padding: 36px 0px 36px 23px;
    box-sizing: border-box;
    div {
      font-size: 24px;
      font-weight: 400;
      position: relative;
      &:before {
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        display: block;
        content: "";
      }
    }
    .info-title {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        width: 29px;
        height: 27px;
        background: url("../../../assets/home/huanbaoting.png") no-repeat;
        background-size: 100% 100%;
      }
    }
    .info-icon1 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #ffc13b;
        box-shadow: 0 0 20px #ffc13b;
        border-radius: 50%;
      }
    }
    .info-icon2 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #caeeff;
        box-shadow: 0 0 20px #caeeff;
        border-radius: 50%;
      }
    }
  }
  .container {
    background: transparent;
  }
}
.video {
  width: 100%;
  max-height: 800px;
}
.yuntai {
  width: 320px;
  height: 320px;
  position: relative;
  margin: 0 auto;
  div {
    position: absolute;
    width: 100px;
    height: 100px;
    background: #2b23d4;
    text-align: center;
    line-height: 100px;
    font-size: 40px;
    font-weight: bold;
    border-radius: 50%;
    cursor: pointer;
  }
  .content {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #00faa8;
  }
  .top {
    top: 0;
    left: 50%;
    transform: translate(-50%, 0);
  }
  .left {
    top: 50%;
    left: 0;
    transform: translate(0, -50%);
  }
  .right {
    top: 50%;
    right: 0;
    transform: translate(0, -50%);
  }
  .bottom {
    bottom: 0;
    left: 50%;
    transform: translate(-50%, 0);
  }
}
</style>
