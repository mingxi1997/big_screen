<template>
  <div>
    <el-dialog
      v-model="dialogVisible"
      title="实时数量监测页面"
      :show-close="false"
    >
      <div class="btn_exit">
        <img
          src="../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="width: 0.13rem;float: right;margin-top:-0.23rem; cursor:pointer;"
        />
      </div>
      <div>
        <img
          src="../../../common/picture/xiaotiane.jpg"
          alt=""
          style="width: 4.9rem; margin-top:0;"
        />
      </div>
      <div style="margin-top: 0.03rem; margin-left:0.4rem; text-align: center">
        <span id="Bird_name" style="font-fanily:'FZMWFont';">小天鹅</span>
        <div style="float: right; margin-right:0.2rem">数量：<span id="Bird_number">15</span> 只</div> 
      </div>
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
  <div class="timeIntervalBox">
    <div class="selectBox">
      <el-date-picker
        v-model="value2"
        type="datetimerange"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        :default-time="defaultTime2"
      />
    </div>
    <div id="TimeInterval" style="width: 100%; height: 100%" v-if="isShowEcharts"></div>
  </div>
</template>

<script>
import * as echarts from "echarts";
import { reactive, ref, onUnmounted } from "vue";

export default {
  name: "TimeInterval",
  data() {
    const dialogVisible = ref(false);
    return {
      dialogVisible,
      //  'graph1':{'a1':false,'a2':false,'a3':false,'a4':false,'a5':false},
      //  'graph2':{'a1':false,'a2':false,'a3':false,'a4':false},
    };
  },
  setup() {
    const dialogVisible = ref(false);
    const value2 = ref("");
    let isShowEcharts = ref(true);
    const defaultTime2 = [
      new Date(2000, 1, 1, 12, 0, 0),
      new Date(2000, 2, 1, 8, 0, 0),
    ]; // '12:00:00', '08:00:00'

    const timeInterval = ref(null);
    //创建一个响应式数据对象
    const state = reactive({
      TimeInterval: ref(),
    });
    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    return{
      isShowEcharts,
    };
  },
  mounted() {
    var myChart = echarts.init(document.getElementById("TimeInterval"));
    var option = {
      backgroundColor: "transparent",
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow",
        },
      },
      grid: {
        left: "3%",
        right: "0",
        top: "20%",
        bottom: "4%",
        containLabel: true,
      },
      xAxis: {
        type: "category",
        data: ["小天鹅", "绿头潜鸭", "白骨顶", "大雁", "苍鹭"],
        axisLine: {
          show: false,
        },
        axisTick: {
          show: false,
        },
        axisLabel: {
          fontSize: "0.06rem",
          rotate: 30, 
          offset: 500,
          distance: 100,
          fontFamily: "Microsoft YaHei",
          color: "#fff",
        },
      },
      yAxis: {
        type: "value",
        // show: false
        axisLabel: {
          fontSize: "0.06rem",
          fontFamily: "Microsoft YaHei",
          color: "#fff",
        },
      },
      colorBy: [
        "#FFCCCC",
        "#CCFFFF",
        "#FFFFCC",
        "#CCCCFF",
        "#FF9966",
        "#CCFF99",
        "#99CCFF",
        "#FFCC99",
        "#99CC99",
        "#6699CC",
        "#CCCCCC",
      ],
      series: [
        {
          name: "2011",
          type: "bar",
          barWidth: "50%",
          symbol: "pin",
          symbolOffset: ["0", "50%"],
          itemStyle: {
            borderColor: "lightblue",
            borderRadius: [10, 10, 2, 2],
            shadowColor: "rgba(255, 255, 255, 0.5)",
            shadowBlur: 10,
          },
          label: {
            show: true,
            // fontSize: '28px',
            position: "top",
            color: "rgba(255, 255, 255, 0.8)",
            textBorderColor: "rgba(91, 243, 255, 0.8)",
            textBorderWidth: 1,
            textShadowColor: "rgba(91, 243, 255, 0.6)",
            textShadowBlur: 5,
            fontSize: "0.07rem",
            fontWeight: 550,
          },
          data: [15, 21, 37, 43, 30],
        },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
    // myChart.on("click", this.nav_open);
    // myChart.on("click", function (param) {
    //   console.log(param.name);
    //   const birdName = param.name;
    //   const birdNumber = param.value;
    //   // console.log(BirdName);
    //   document.getElementById("Bird_name").innerHTML = birdName;
    //   document.getElementById("Bird_number").innerHTML = birdNumber;
    // });
  },
  methods: {
    nav_open() {
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
.timeIntervalBox {
  width: 100%;
  height: 100%;
  position: relative;
  .selectBox {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 1;
  }
}
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.8rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
</style>
