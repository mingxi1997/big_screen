<template>
  <div class="realTimeBox">
    <div class="itemBox">
      <div class="realTime-item" v-for="(item, index) in list" :key="index">
        {{ item }}
      </div>
      <div class="realTime-item" v-for="(item, index) in list" :key="index">
        {{ item }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "RealTime",
  components: {},
  props: [],
  emits: [],
  setup(props, context) {
    const list = [
      "AI 监测报警:两只孙悟空抢夺人类幼崽的蛋糕",
      "传感器报警：湖里的水位接近警戒值，提示防范",
      "设备离线报警：山上的摄像头被孙悟空抢走了",
      "AI 监测报警:两只孙悟空抢夺人类幼崽的蛋糕",
      "传感器报警：湖里的水位接近警戒值，提示防范",
      "设备离线报警：山上的摄像头被孙悟空抢走了",
    ];
    return { list };
  },
};
</script>

<style lang="less" scoped>
.realTimeBox {
  width: 100%;
  height: 347px;
  overflow: hidden;
  .itemBox {
    width: 100%;
    .realTime-item {
      height: 80px;
      line-height: 80px;
      text-indent: 3em;
      position: relative;
      font-size: 31px;
      font-weight: 400;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;

      &:before {
        position: absolute;
        top: 50%;
        left: 30px;
        transform: translateY(-50%);
        display: block;
        content: "";
        width: 34px;
        height: 34px;
        background: url("../../../assets/home/voice.png") no-repeat;
        background-size: 100% 100%;
      }
    }
    animation: myfirst 5s ease infinite;
    animation-timing-function: linear;
  }
  @keyframes myfirst {
    from {
      transform: translateY(0);
    }
    to {
      transform: translateY(-50%);
    }
  }
}
</style>
