<template>
  <div class="situation_box">
    <div class="situation_title">监测点建设状况:</div>
    <div class="situation_item" v-for="(item, index) in list">
      <div>{{ item.title }}</div>
      <div>{{ item.sub }}</div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    const list = [
      {
        sub: 23,
        title: "样地",
      },
      {
        sub: 21,
        title: "样线",
      },
      {
        sub: 15,
        title: "红外相机",
      },
      {
        sub: 50,
        title: "AI监测",
      },
      {
        sub: 23,
        title: "气象站",
      },
      {
        sub: 35,
        title: "浮标",
      },
      {
        sub: 13,
        title: "eDNA监测点",
      },
      {
        sub: 6,
        title: "塔吊",
      },
    ];
    return {
      list,
    };
  },
};
</script>

<style lang="less">
.situation_box {
  margin-left: 2.5%;
  margin-bottom: 0.5%;
  padding-left: 5%;
  width: 90%;
  height: 0.9rem;
  background: url("../../../assets/infoBg2.png") no-repeat;
  background-size: 100% 100%;
  .situation_title {
    position: relative;
    left: 2%;
    top: 10%;
    font-size: 0.1rem;
    font-family: "Microsoft YaHei";
    line-height: 0.15rem;
    margin-bottom: 0.02rem;
  }
  .situation_item {
    display: inline-block;
    width: 252px;
    height: 180px;
    padding-top: 0.08rem;
    background: url("../../../assets/imgbg2.png") no-repeat;
    background-size: 100% 100%;
    text-align: center;
    font-size: 0.09rem;
    font-weight: 600;
    line-height: 0.2rem;
    margin-top: 0.06rem;
    margin-left: 0.068rem;
    margin-right: 0.068rem;
  }
}
</style>
