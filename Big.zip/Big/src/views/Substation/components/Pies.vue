<template>
  <div>
    <el-dialog v-model="dialogVisible" title="种群占比" :show-close="false">
      <div class="btn_exit">
        <img
          src="../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="width: 0.13rem; float: right; margin-top: -0.23rem"
        />
      </div>
      <div>
        <img
          src="../../../common/picture/xiaotiane.jpg"
          alt=""
          style="width: 4.9rem; margin-top: 0"
        />
      </div>
      <div style="margin-top: 0.03rem; margin-left: 0.4rem; text-align: center">
        <span id="Group_name" style="font-fanily: 'FZMWFont'">绿头潜鸭</span>
        <div style="float: right; margin-right: 0.2rem">
          数量：<span id="Group_number">44</span> 只
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
  <div id="population" style="width: 100%; height: 1rem"></div>
</template>

<script>
import * as echarts from "echarts";
import { useRouter } from "vue-router";
import { ref } from "vue";
export default {
  name: "Population",
  data() {
    const dialogVisible = ref(false);
    return { dialogVisible };
  },
  mounted() {
    var myChart = echarts.init(document.getElementById("population"));
    var option = {
      dataset: [
        {
          source: [
            ["类别", "数量", "种群"],
            ["被子植物", 1552, "陆生维管束植物"],
            ["裸子植物", 32, "陆生维管束植物"],
            ["蕨类植物", 65, "陆生维管束植物"],
            ["鸟类", 373, "陆生脊椎动物"],
            ["哺乳动物", 105, "陆生脊椎动物"],
            ["爬行动物", 36, "陆生脊椎动物"],
            ["两栖动物", 20, "陆生脊椎动物"],
            ["其他昆虫", 1764, "陆生昆虫"],
            ["蝴蝶", 121, "陆生昆虫"],
            ["浮游植物", 753, "水生生物"],
            ["大型无脊椎动物", 357, "水生生物"],
            ["鱼类", 200, "水生生物"],
            ["浮游动物", 465, "水生生物"],
            ["水生植物", 252, "水生生物"],
            ["哺乳动物", 1, "水生生物"],
          ],
        },
        {
          transform: {
            type: "filter",
            config: { dimension: "种群", value: "陆生维管束植物" },
          },
        },
        {
          transform: {
            type: "filter",
            config: { dimension: "种群", value: "陆生脊椎动物" },
          },
        },
        {
          transform: {
            type: "filter",
            config: { dimension: "种群", value: "陆生昆虫" },
          },
        },
        {
          transform: {
            type: "filter",
            config: { dimension: "种群", value: "水生生物" },
          },
        },
      ],
      series: [
        {
          type: "pie",
          center: ["50%", "0%"],
          radius: "46%",
          datasetIndex: 1,
          avoidLabelOverlap: true,
          color: [
            "#028090",
            "#9BC53D",
            "#F0F3BD",
            "#02C39A",
            "#00A896",
            "#E9C46A",
          ],
          label: {
            position: "outside",
            formatter: '{b}',
            color: "white",
            fontSize: "0.04rem",
          },
          labelLine: {
            length: "3%",
            length2: "2%",
            smooth: 0.3,
          },
        },
        {
          type: "pie",
          center: ["50%", "30%"],
          radius: "46%",
          datasetIndex: 2,
          avoidLabelOverlap: true,
          color: [
            "#028090",
            "#F0F3BD",
            "#9BC53D",
            "#00A896",
            "#02C39A",
            "#E9C46A",
          ],
          label: {
            position: "outside",
            formatter: '{b}',
            color: "white",
            fontSize: "0.04rem",
          },
          labelLine: {
            length: "3%",
            length2: "2%",
            smooth: 0.3,
          },
        },
        {
          type: "pie",
          center: ["50%", "60%"],
          radius: "46%",
          datasetIndex: 3,
          avoidLabelOverlap: true,
          color: [
            "#F0F3BD",
            "#00A896",
            "#E9C46A",
            "#02C39A",
            "#9BC53D",
            "#028090",
          ],
          label: {
            position: "outside",
            formatter: '{b}',
            color: "white",
            fontSize: "0.04rem",
          },
          labelLine: {
            length: "3%",
            length2: "2%",
            smooth: 0.3,
          },
        },
        {
          type: "pie",
          center: ["50%", "100%"],
          radius: "46%",
          datasetIndex: 4,
          avoidLabelOverlap: true,
          color: [
            "#028090",
            "#F0F3BD",
            "#9BC53D",
            "#00A896",
            "#02C39A",
            "#E9C46A",
          ],
          label: {
            position: "outside",
            formatter: '{b}',
            color: "white",
            fontSize: "0.04rem",
          },
          labelLine: {
            length: "3%",
            length2: "2%",
            smooth: 0.3,
          },
          labelLayout: {
            moveOverlap: 'shiftY',
          }
        },
      ],
      // Optional. Only for responsive layout:
      media: [
        {
          query: { minAspectRatio: 1 },
          option: {
            series: [
              { center: ["18%", "50%"] },
              { center: ["40%", "50%"] },
              { center: ["62%", "50%"] },
              { center: ["84%", "50%"] },
            ],
          },
        },
        // {
        //   option: {
        //     series: [
        //       { center: ["50%", "20%"] },
        //       { center: ["50%", "40%"] },
        //       { center: ["50%", "60%"] },
        //       { center: ["50%", "80%"] },
        //     ],
        //   },
        // },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
    // myChart.on("click", function (params) {
    //   // 在用户点击后控制台打印数据的名称
    //   console.log(params);
    // });
    myChart.on("click", this.nav_open);
    myChart.on("click", function (param) {
      // console.log(param.name);
      const groupName = param.name;
      const groupNumber = param.value;
      // console.log(BirdName);
      document.getElementById("Group_name").innerHTML = groupName;
      document.getElementById("Group_number").innerHTML = groupNumber[1];
    });
  },
  methods: {
    nav_open() {
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.8rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
</style>