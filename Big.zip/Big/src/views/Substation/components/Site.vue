<template>
  <div class="siteBox">
    <div class="selectBox">
      <el-select
        v-model="value"
        class="m-2"
        placeholder="请选择当前监测点"
        size="large"
      >
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>
    </div>
    <div class="site-title">主要保护对象管理:</div>
    <div class="site-item" v-for="(item, index) in list" :key="index">
      <div class="sitem-text">
        <img
          src="../../../assets/substation/zhandianjiance.png"
          alt=""
          @click="openDia"
        />
        {{ item.sub }}<span>只</span>
      </div>
      <div class="sitem-title">{{ item.title }}</div>
    </div>
    <div>
      <div class="dia" v-if="dialogVisible">
        <button @click="openDia">关闭</button>
        <br />
        <div><Ai /></div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import Ai from "./Ai.vue";

export default {
  name: "Site",
  components: {
    Ai,
  },
  props: [],
  emits: [],
  setup(props, context) {
    const dialogVisible = ref(false);
    const value = ref("");

    const options = [
      {
        value: "1",
        label: "1号机",
      },
      {
        value: "2",
        label: "2号机",
      },
      {
        value: "3",
        label: "3号机",
      },
      {
        value: "4",
        label: "4号机",
      },
      {
        value: "5",
        label: "5号机",
      },
    ];
    const list = [
      {
        sub: 23,
        title: "白鹭",
      },
      {
        sub: 21,
        title: "绿头潜鸭",
      },
      {
        sub: 15,
        title: "白骨顶",
      },
      {
        sub: 50,
        title: "大雁",
      },
      {
        sub: 73,
        title: "野鸭",
      },
      {
        sub: 35,
        title: "白鹤",
      },
      {
        sub: 33,
        title: "鹧鸪",
      },
      {
        sub: 6,
        title: "鸳鸯",
      },
    ];

    const openDia = (e) => {
      // console.log(213);
      dialogVisible.value = !dialogVisible.value;
    };

    return {
      list,
      value,
      dialogVisible,
      options,
      openDia,
    };
  },
};
</script>

<style lang="less" scoped>
.siteBox {
  width: 100%;
  height: 645px;
  padding-top: 113px;
  padding-left: 14px;
  box-sizing: border-box;
  position: relative;
  .selectBox {
    position: absolute;
    top: 0;
    right: 10%;
    z-index: 1;
  }
  .site-title {
    margin-top: -8.5%;
    margin-left: 2%;
    margin-bottom: 6%;
    font-size: 0.08rem;
  }
  .site-item {
    margin-right: 20px;
    margin-bottom: 60px;
    display: inline-block;
    vertical-align: top;
    text-align: center;
    width: 168px;
    .sitem-text {
      width: 100%;
      height: 168px;
      line-height: 168px;
      font-size: 33px;
      font-family: Source Han Sans CN;
      font-weight: bold;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      position: relative;
      img {
        position: absolute; 
        cursor:pointer;
        top: 0;
        left: 0;
        display: block;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        animation: dorotate 3s ease-in-out infinite;
        animation-timing-function: linear;
      }
      @keyframes dorotate {
        from {
          transform: rotate(0deg);
        }
        to {
          transform: rotate(360deg);
        }
      }
      span {
        font-size: 20px;
      }
    }
    .sitem-title {
      font-size: 26px;
      font-weight: 400;
    }
  }
  .dia {
    background: rgba(220, 220, 255, 0.3);
    width: 300%;
    z-index: 9;
    position: relative;
    margin-left: 70%;
    padding: 3%;
    border: 2px solid #1858ce;
    border-radius: 0.06rem;
    button { 
        cursor:pointer;
      float: right;
      width: 4%;
      color: rgb(0, 0, 0);
      background: darkgrey;
      opacity: 0.8;
      border-radius: 0.025rem;
    }
  }
}
</style>
