<template>
  <div>
    <el-dialog
      v-model="dialogVisible"
      title="种群占比"
      :show-close="false"
    >
      <div class="btn_exit">
        <img
          src="../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="width: 0.13rem; float: right; margin-top: -0.23rem; cursor:pointer;"
        />
      </div>
      <div>
        <img
          src="../../../common/picture/xiaotiane.jpg"
          alt=""
          style="width: 4.9rem; margin-top: 0"
        />
      </div>
      <div style="margin-top: 0.03rem; margin-left:0.4rem; text-align: center">
        <span id="Group_name" style="font-fanily:'FZMWFont';">绿头潜鸭</span>
        <div style="float: right; margin-right:0.2rem">数量：<span id="Group_number">44</span> 只</div> 
      </div>
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
  <div id="population" style="width: 100%; height: 1rem" v-if="isShowEcharts"></div>
</template>

<script>
import * as echarts from "echarts";
import { ref, onUnmounted } from "vue";
export default {
  name: "Population",
  setup(){
    let isShowEcharts = ref(true);

    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    return{
      isShowEcharts,
    };
  },
  data() {
    const dialogVisible = ref(false);
    return { dialogVisible };
  },
  mounted() {
    var myChart = echarts.init(document.getElementById("population"));
    var option = {
      backgroundColor: "transparent",
      legend: {
        show: true,
        left: "70%",
        bottom: "10%",
        top: "10%",
        // // formatter: '{name}:{value}',
        // formatter: function (name,value) {
        //   return name + value;
        // },
        textStyle: {
          fontSize: "0.065rem",
          fontWeight: 400,
          color: "white",
        },
      },
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow",
        },
      },
      grid: {
        left: "0",
        right: "0",
        // top: "1rem",
        // bottom: '-100px',
      },
      avoidLabelOverlap: true,
      color: ["#EF476F", "#FFD166", "#06D6A0", "#F0A6CA", "#5BC0EB", "#FA7921"],
      series: [
        {
          name: "Nightingale Chart",
          type: "pie",
          center: ["35%", "52%"],
          radius: ["60%", "90%"],
          // roseType: 'radius',
          label: {
            // fontSize: '18px',
            position: "inner",
            formatter: "{d}%",
            color: "white",
            textBorderColor: "rgba(91, 243, 255, 0.8)",
            textBorderWidth: 1,
            textShadowColor: "rgba(91, 243, 255, 0.6)",
            textShadowBlur: 5,
            fontFamily: "Microsoft YaHei",
            fontSize: "0.08rem",
            fontWeight: "600",
            // formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          itemStyle: {
            borderRadius: 3,
            borderColor: "rgba(255, 255, 255, 0.4)",
            shadowColor: "rgba(255, 255, 255, 0.5)",
            shadowBlur: 5,
          },
          data: [
            { value: 44, name: "绿头潜鸭" },
            { value: 38, name: "苍鹭" },
            { value: 34, name: "白鹭" },
            { value: 28, name: "白骨顶" },
            { value: 24, name: "丹顶鹤" },
            { value: 18, name: "大雁" },
          ],
        },
        {
          type: "pie",
          center: ["35%", "52%"],
          radius: [0, "50%"],
          // roseType: 'radius',
          label: {
            // fontSize: '18px',
            show: false,
            position: "inner",
            formatter: "{b}:\n{d}%",
            color: "white",
            fontFamily: "Microsoft YaHei",
            fontSize: "0.065rem",
            fontWeight: "600",
            // formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          itemStyle: {
            opacity: 0.5,
          },
          emphasis: {
            disable: false,
            scale: false,
          },
          data: [
            { value: 44, name: "绿头潜鸭" },
            { value: 38, name: "苍鹭" },
            { value: 34, name: "白鹭" },
            { value: 28, name: "白骨顶" },
            { value: 24, name: "丹顶鹤" },
            { value: 18, name: "大雁" },
          ],
        },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
    // myChart.on("click", function (params) {
    //   // 在用户点击后控制台打印数据的名称
    //   console.log(params);
    // });
    myChart.on("click", this.nav_open);
    myChart.on("click", function (param) {
      // console.log(param.name);
      const groupName = param.name;
      const groupNumber = param.value;
      // console.log(BirdName);
      document.getElementById("Group_name").innerHTML = groupName;
      document.getElementById("Group_number").innerHTML = groupNumber;
    });
  },
  methods: {
    nav_open() {
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.8rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
</style>