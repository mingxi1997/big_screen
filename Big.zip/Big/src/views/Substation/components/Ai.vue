<template>
  <div class="aiBox">
    <div class="ai-item">
      <div class="imgBox">
        <div class="imgBox-item">
          <div v-for="(item, index) in srcList" :key="index">
            <div class="lefttop"></div>
            <div class="leftbottom"></div>
            <div class="righttop"></div>
            <div class="rightbottom"></div>
            <img @click="doIsViewer(index)" :src="item" />
          </div>
          <div v-for="(item, index) in srcList" :key="index">
            <div class="lefttop"></div>
            <div class="leftbottom"></div>
            <div class="righttop"></div>
            <div class="rightbottom"></div>
            <img @click="doIsViewer(index)" :src="item" />
          </div>
        </div>
      </div>
    </div>
    <div style="float:center;padding-left: '40%'">
      <el-image-viewer
        @close="close"
        v-if="isViewer"
        :initial-index="initial"
        :url-list="srcList"
        :teleported="true"
        hide-on-click-modal
        style="width: 6rem"
      ></el-image-viewer>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";

export default {
  name: "Ai",
  setup() {
    const isViewer = ref(false);
    const initial = ref(0);
    const doIsViewer = (index) => {
      console.log(index);
      initial.value = index * 1;
      isViewer.value = true;
    };
    const close = () => {
      isViewer.value = false;
    };
    const srcList = [
      "http://www.jobmz.com:6060/jwbird/img/bird2.8b7b2f76.jpg",
      "http://www.jobmz.com:6060/jwbird/img/bird7.497e8f3c.jpg",
      "http://www.jobmz.com:6060/jwbird/img/bird1.e28df2b5.jpg",
      "http://www.jobmz.com:6060/jwbird/img/bird3.4902cd2f.jpg",
    ];
    return {
      srcList,
      initial,
      close,
      doIsViewer,
      isViewer,
    };
  },
};
</script>

<style lang="less" scoped>
.el-image-viewer__wrapper {
  margin-left: 20%;
}
.aiBox {
  .ai-item {
    padding-top: 30px;
    box-sizing: border-box;
    //overflow: hidden;
    .imgBox {
      height: 317px;
      padding: 0 1%;
      box-sizing: border-box;
      overflow: hidden;
      overflow-x: scroll;
      white-space: nowrap;
      .imgBox-item {
        width: 5910px;
        animation: mys 12s ease infinite;
        animation-timing-function: linear;
        div {
          width: 510px;
          height: 100%;
          display: inline-block;
          vertical-align: top;
          position: relative;
          padding: 10px;
          box-sizing: border-box;
          img {
            display: block;
            width: 100%;
            height: 100%;
            cursor: pointer;
          }
          &:not(:last-child) {
            margin-right: 90px;
          }
          .lefttop,
          .leftbottom,
          .righttop,
          .rightbottom {
            position: absolute;
            width: 57px;
            height: 45px;
            margin: 0;
          }
          .lefttop {
            top: 0;
            left: 0;
            border-top: 2px solid #20dbfd;
            border-left: 2px solid #20dbfd;
          }
          .leftbottom {
            left: 0;
            bottom: 0;
            border-left: 2px solid #20dbfd;
            border-bottom: 2px solid #20dbfd;
          }
          .righttop {
            top: 0;
            right: 0;
            border-top: 2px solid #20dbfd;
            border-right: 2px solid #20dbfd;
          }
          .rightbottom {
            right: 0;
            bottom: 0;
            border-right: 2px solid #20dbfd;
            border-bottom: 2px solid #20dbfd;
          }
        }
      }
    }
  }
}
@keyframes mys {
  from {
    transform: translateX(0);
  }
  to {
    transform: translateX(-40%);
  }
}
</style>
