<template>
  <div class="mapBox">
    <div class="lefttop"></div>
    <div class="leftbottom"></div>
    <div class="righttop"></div>
    <div class="rightbottom"></div>
    <div
      class="container"
      id="container1"
      style="height: 100%; background: transparent !important"
      v-if="isShowMap"
    ></div>
    <!--    <div class="info">-->
    <!--      <div class="info-title">江苏省环保厅</div>-->
    <!--      <div class="info-icon1">已建成站点</div>-->
    <!--      <div class="info-icon2">未建成站点</div>-->
    <!--    </div>-->
    <div class="title">
      <img
        src="../../../assets/back_home.png"
        alt=""
        @click="doHome"
        style="
          width: 0.4rem;
          float: right;
          margin-top: -0.18rem;
          margin-right: -0.05rem;
          cursor: pointer;
        "
      />
    </div>
  </div>
  <div>
    <el-dialog
      v-model="dialogVisible"
      custom-class="Dialog"
      :modal="true"
      :show-close="false"
      width="50%"
      destroy-on-close
      title="南京沿江湿地站检测点："
    >
      <!-- <template #header>
        <span style="font-size: 0.1rem; color: white"
          >南京沿江湿地站检测点：</span
        >
      </template> -->
      <div class="btn">
        <!-- <el-button class="btn_yuntai">左</el-button>
        <el-button class="btn_yuntai">上</el-button>
        <el-button class="btn_yuntai">右</el-button>
        <el-button class="btn_yuntai">下</el-button> -->
        <div class="btn_exit">
          <img
            src="../../../assets/shutdown.png"
            alt=""
            @click="dialogVisible = false"
            style="width: 0.13rem; cursor: pointer"
          />
        </div>
      </div>
      <div style="width: 102%; height: 100%">
        <div class="video-container">
          <video-player ref="videoRef" class="video" :options="videoOptions" />
        </div>
        <div class="kongzhi">
          <div class="ptz_control">
            <el-button
              circle="true"
              color="transparent"
              style="
                padding: 0.014rem;
                color: white;
                font-size: 0.13rem;
                float: left;
                margin-left: 0.34rem;
                maigin-top: 0.1rem;
                margin-bottom: 0.165rem;
                margin-right: 0.5rem;
                --el-button-hover-bg-color: transparent;
                --el-button-hover-border-color: transparent;
                --el-button-active-bg-color: rgba(139, 153, 158, 0.5);
                --el-button-active-border-color: transparent;
              "
              size="large"
            >
              ⇧
            </el-button>
            <el-button
              circle="true"
              color="transparent"
              style="
                padding: 0.014rem;
                color: white;
                font-size: 0.13rem;
                float: left;
                margin-left: 0rem;
                maigin-top: 2.2rem;
                --el-button-hover-bg-color: transparent;
                --el-button-hover-border-color: transparent;
                --el-button-active-bg-color: rgba(139, 153, 158, 0.5);
                --el-button-active-border-color: transparent;
              "
              size="large"
            >
              ⇦
            </el-button>
            <el-button
              circle="true"
              color="transparent"
              style="
                padding: 0.014rem;
                color: white;
                font-size: 0.13rem;
                float: right;
                margin-left: 0.5rem;
                maigin-top: 0.35rem;
                margin-bottom: 0.175rem;
                --el-button-hover-bg-color: transparent;
                --el-button-hover-border-color: transparent;
                --el-button-active-bg-color: rgba(139, 153, 158, 0.5);
                --el-button-active-border-color: transparent;
              "
              size="large"
            >
              ⇨
            </el-button>
            <el-button
              circle="true"
              color="transparent"
              style="
                padding: 0.014rem;
                color: white;
                font-size: 0.13rem;
                float: left;
                margin-left: 0.35rem;
                maigin-top: 0.4rem;
                margin-right: 0.5rem;
                margin-bottom: 0.092rem;
                --el-button-hover-bg-color: transparent;
                --el-button-hover-border-color: transparent;
                --el-button-active-bg-color: rgba(139, 153, 158, 0.5);
                --el-button-active-border-color: transparent;
              "
              size="large"
            >
              ⇩
            </el-button>
            <el-button
              size="large"
              color="transparent"
              style="
                padding-top: 0.055rem;
                padding-bottom: 0.055rem;
                padding-left: 0.15rem;
                padding-right: 0.155rem;
                float: left;
                margin-left: 0.04rem;
                --el-button-hover-bg-color: transparent;
                --el-button-hover-border-color: transparent;
                --el-button-active-bg-color: rgba(139, 153, 158, 0.5);
                --el-button-active-border-color: transparent;
              "
            >
            </el-button>
            <el-button
              size="large"
              color="transparent"
              style="
                padding-top: 0.055rem;
                padding-bottom: 0.055rem;
                padding-left: 0.15rem;
                padding-right: 0.165rem;
                float: left;
                margin-left: 0.15rem;
                --el-button-hover-bg-color: transparent;
                --el-button-hover-border-color: transparent;
                --el-button-active-bg-color: rgba(139, 153, 158, 0.5);
                --el-button-active-border-color: transparent;
              "
            >
            </el-button>
          </div>
          <!-- <img
            src="../../../assets/ptz_control.png"
            style="width: 0.8rem; margin-left: 0.13rem; margin-top: 40%"
          /> -->
        </div>
      </div>
      <!-- <div class="yuntai">
      <div class="top">上</div>
      <div class="left">左</div>
      <div class="content" @click="play">播放</div>
      <div class="right">右</div>
      <div class="bottom">下</div>
    </div> -->
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import map from "@/utils/map";
import { useRouter } from "vue-router";
import { onUnmounted, ref, watch } from "vue";
import VideoPlayer from "../components/VideoPlayer.vue";
import {
  ArrowLeft,
  Edit,
  Share,
  Delete,
  Search,
  Upload,
} from "@element-plus/icons-vue";

import "video.js/dist/video-js.css";

export default {
  name: "Map",
  components: {
    VideoPlayer,
  },
  props: [],
  emits: [],
  setup(props, context) {
    const router = useRouter();
    const dialogVisible = ref(false);
    let mymap = null;
    let myAMap = null;
    let isShowMap = ref(true);
    let infoWindow = null;
    const info = ref(null);
    const doHome = () => {
      router.push("/");
    };
    onUnmounted(() => {
      isShowMap.value = false;
    });

    map.mapUI("70f795a63de3e135ddaf4b1a637f33a5").then((AMap) => {
      myAMap = AMap;
      mymap = new AMap.Map("container1", {
        resizeEnable: true,
        zoom: 13, // 级别
        center:[118.718507, 31.905671],
        mapStyle: "amap://styles/darkblue",
      });
      infoWindow = new AMap.InfoWindow({
        // isCustomElement:
        isCustom: true,
        offset: new AMap.Pixel(0, -30),
      });
      const infoWindowClose = () => {
        infoWindow.close();
      };
      mymap.on("complete", () => {
        [
          {
            id: 1,
            position: [118.642683, 31.956352],
          },
          {
            id: 2,
            position: [118.672908, 31.996092],
          },
          {
            id: 3,
            position: [118.731847, 32.085125],
          },
        ].forEach((d) => {
          const marker = new myAMap.Marker({
            position: d.position,
            offset: new myAMap.Pixel(-8, -30),
            icon: require("../../../assets/substation/camera.png"),
            map: mymap,
          });
          marker.d = d;
          marker.content = `<div style="font-size: 24px;color: #fa9600;background-color: rgba(255,255,255,0.5);">南京检测点：${d.id}号点</div>`;
          marker.on("mouseover", markerClick);
          marker.on("click", myVideo);
          // marker.on('mouseout', infoWindowClose)
          marker.emit("mouseover", { target: marker });
        });
      });
    });
    const markerClick = (e) => {
      info.value = e.target.d;
      infoWindow.setContent(e.target.content);
      infoWindow.open(mymap, e.target.getPosition());
    };
    const myVideo = (e) => {
      info.value = e.target.d;
      console.log(213);
      dialogVisible.value = true;
    };
    const videoRef = ref(null);
    // watch(dialogVisible, (newValue) => {
    //   // paused
    //   if (!newValue) {
    //     // console.log(videoRef.value)
    //     videoRef.pause();
    //   }
    // });
    // const play = () => {
    //   console.log(videoRef.value.play);
    //   videoRef.value.play();
    // };
    return {
      videoRef,
      isShowMap,
      // play,
      dialogVisible,
      doHome,
      videoOptions: {
        autoplay: true,
        controls: true,
        loop: true, //视频一结束就重新开始
        aspectRatio: "16:9",
        fullscreen: {
          options: { navigationUI: "hide" },
        },
        sources: [
          {
            src: require("../../../common/video/yan.7f04c582.mp4"),
            type: "video/mp4",
            // src: "http://36.152.9.59:39980/live/0/hls.m3u8?secret=1443ffb0-2f5b-4c85-ad33-55ccfe67c2f1",
            // type: "application/vnd.apple.mpegurl",
          },
        ],
      },
    };
  },
};
</script>

<style lang="less" scoped>
.mapBox {
  position: relative;
  height: 1450px;
  padding: 10px 129px 78px 129px;
  box-sizing: border-box;
  .lefttop,
  .leftbottom,
  .righttop,
  .rightbottom {
    position: absolute;
    width: 150px;
    height: 120px;
  }
  .lefttop {
    top: 0;
    left: 119px;
    border-top: 2px solid #20dbfd;
    border-left: 2px solid #20dbfd;
  }
  .leftbottom {
    left: 119px;
    bottom: 68px;
    border-left: 2px solid #20dbfd;
    border-bottom: 2px solid #20dbfd;
  }
  .righttop {
    top: 0;
    right: 119px;
    border-top: 2px solid #20dbfd;
    border-right: 2px solid #20dbfd;
  }
  .rightbottom {
    right: 119px;
    bottom: 68px;
    border-right: 2px solid #20dbfd;
    border-bottom: 2px solid #20dbfd;
  }
  .title {
    position: absolute;
    right: 170px;
    top: 90px;
    font-size: 35px;
    font-weight: 400;
    text-align: right;
  }
  .info {
    position: absolute;
    left: 208px;
    bottom: 126px;
    width: 236px;
    height: 223px;
    background: url("../../../assets/home/kuag.png") no-repeat;
    background-size: 100% 100%;
    padding: 36px 0px 36px 23px;
    box-sizing: border-box;
    div {
      font-size: 24px;
      font-weight: 400;
      position: relative;
      &:before {
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        display: block;
        content: "";
      }
    }
    .info-title {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        width: 29px;
        height: 27px;
        background: url("../../../assets/home/huanbaoting.png") no-repeat;
        background-size: 100% 100%;
      }
    }
    .info-icon1 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #ffc13b;
        box-shadow: 0 0 20px #ffc13b;
        border-radius: 50%;
      }
    }
    .info-icon2 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #caeeff;
        box-shadow: 0 0 20px #caeeff;
        border-radius: 50%;
      }
    }
  }
  .container {
    background: transparent;
    background-color: #20dbfd;
    border: #20dbfd;
    color: white;
    font-size: 0.08rem;
  }
}
.body {
  background-color: #4cc5fd;
  height: 100%;
  width: 100%;
}
.btn {
  height: 50px;
}
.Dialog {
  // background-color: #20dbfd;
  // opacity: 1;
}
.video-container {
  border-color: transparent;
  float: left;
  width: 78.8%;
  margin-left: -0.85%;
  margin-top: -3.2%;
}
.kongzhi {
  float: left;
  width: 21%;
  height: 94.6%;
  background-color: #ababab;
  margin-top: -0.65%;
  // margin-right: 10%;
}
.fangxiang {
  float: center;
  margin-right: 100px;
  padding-right: 100%;
}
.ptz_control {
  background: url("../../../assets/ptz_control.png") no-repeat;
  background-size: 100% 100%;
  width: 80%;
  height: 48%;
  margin-left: 10%;
  margin-top: 40%;
}
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #000000;
  height: 2.34rem;
}
/deep/ .el-dialog__footer {
  background: #000000;
}
/deep/ .el-button {
  --el-button-hover-bg-color: transparent;
}
.btn_yuntai {
  color: "white";
  background-color: #4cc5fd;
  font-size: 28px;
  padding: 10px;
  width: 200px;
  height: 50px;
  margin-left: 120px;
  margin-right: 120px;
  margin-top: 0;
}
.btn_exit {
  color: "white";
  font-size: 30px;
  float: right;
  width: 100px;
  height: 80px;
  opacity: 0.8;
  padding: 20px;
  margin-right: -3%;
  margin-top: -5.8%;
}
.video {
  margin-top: 50px;
  width: 100%;
  max-height: 1200px;
}
.yuntai {
  width: 320px;
  height: 320px;
  position: relative;
  margin: 0 auto;
  div {
    position: absolute;
    width: 100px;
    height: 100px;
    background: #2b23d4;
    text-align: center;
    line-height: 100px;
    font-size: 40px;
    font-weight: bold;
    border-radius: 50%;
    cursor: pointer;
  }
  .content {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #00faa8;
  }
  .top {
    top: 0;
    left: 50%;
    transform: translate(-50%, 0);
  }
  .left {
    top: 50%;
    left: 0;
    transform: translate(0, -50%);
  }
  .right {
    top: 50%;
    right: 0;
    transform: translate(0, -50%);
  }
  .bottom {
    bottom: 0;
    left: 50%;
    transform: translate(-50%, 0);
  }
}
</style>
