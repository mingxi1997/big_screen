<template>
  <div class="home">
    <div class="left">
      <MyTitle>实时物种管理</MyTitle>
      <div class="manage">
        <div class="manage_left"><TimeInterval /></div>
        <div class="manage_right"><Type /></div>
      </div>
      <MyTitle>站点监测</MyTitle>
      <Site />
      <MyTitle>环境因子</MyTitle>
      <Environment />
    </div>
    <div class="content">
      <div class="content_head">
        <Situation />
      </div>
      <div class="content_body">
      <Mapnew />
      </div>
    </div>
  </div>
</template>

<script>
import MyTitle from "@/views/Home/components/MyTitle";
import MyTitle1 from "./components/MyTitle";
import Situation from "./components/Situation";
import Mapnew from "./components/Mapnew";
import RealTime from "./components/RealTime";
import Environment from "./components/Environment";
import Type from "./components/Type";
import Population from "./components/Population";
import Site from "./components/Site";
import TimeInterval from "./components/TimeInterval";
import Ai from "./components/Ai";

export default {
  name: "Substation",
  components: {
    Ai,
    Situation,
    Mapnew,
    MyTitle,
    MyTitle1,
    RealTime,
    Environment,
    Type,
    Population,
    Site,
    TimeInterval,
  },
  props: [],
  emits: [],
  setup(props, context) {
    return {};
  },
};
</script>

<style lang="less" scoped>
.home {
  margin: 38px;
  padding-top: 14px;
  .manage {
    margin-top: 5%;
    width: 100%;
    height: 400px;
    .manage_left {
      width: 48%;
      height: 100%;
      margin-right: 4%;
      float: left;
    }
    .manage_right {
      width: 48%;
      height: 100%;
      float: left;
    }
  }
  .left {
    width: 858px;
    display: inline-block;
    vertical-align: top;
  }
  .content {
    width: 2880px;
    height: 1800px;
    display: inline-block;
    vertical-align: top;
    .infosBox {
      padding-left: 50px;
      padding-right: 100px;
    }
  }
}
</style>
