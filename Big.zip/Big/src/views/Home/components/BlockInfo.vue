<template>
  <div class="blockInfo">
    <div class="blockInfoBox">
      <div class="blockInfoBox-item blockInfoBox-item1">
        <div class="blockInfo-title">观测站场总数</div>
        <router-link to="/total"><div class="blockInfo-text">20</div></router-link>
      </div>
      <div class="blockInfoBox-item blockInfoBox-item2">
        <div class="blockInfo-title">沿江热点区域</div>
        <router-link to="/jiang"><div class="blockInfo-text">5</div></router-link>
      </div>
      <div class="blockInfoBox-item blockInfoBox-item3">
        <div class="blockInfo-title">沿大运河热点区域</div>
        <router-link to="/he"><div class="blockInfo-text">5</div></router-link>
      </div>
      <div class="blockInfoBox-item blockInfoBox-item4">
        <div class="blockInfo-title">沿海热点区域</div>
        <router-link to="/hai"><div class="blockInfo-text">4</div></router-link>
      </div>
      <div class="blockInfoBox-item blockInfoBox-item5">
        <div class="blockInfo-title">低山丘陵热点区域</div>
        <router-link to="/sen"><div class="blockInfo-text">6</div></router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from "vue-router";
export default {
  name: "BlockInfo",
  components: {},
  props: [],
  emits: [],
  setup(props, context) {
    return {};
  },
};
</script>

<style lang="less" scoped>
.blockInfo {
  text-align: center;
  .blockInfoBox {
    display: inline-block;
    margin-bottom: 47px;
    height: 265px;
    .blockInfoBox-item {
      display: inline-block;
      vertical-align: top;
      height: 265px;
      text-align: center;
      .blockInfo-title {
        font-size: 36px;
        font-family: "Microsoft YaHei";
        font-weight: 400;
        height: 132px;
        line-height: 132px;
      }
      .blockInfo-text {
        text-decoration-line: none;
        font-size: 92px;
        font-weight: bold;
        color: #20dbfd;
        animation: shine 5s infinite;
        @keyframes shine {
          0% {
            text-shadow: #20dbfd 0px 0px 2px;
          }
          25% {
            text-shadow: #20dbfd 0px 0px 15px;
          }
          50% {
            text-shadow: #20dbfd 0px 0px 20px;
          }
          75% {
            text-shadow: #20dbfd 0px 0px 15px;
          }
          100% {
            text-shadow: #20dbfd 0px 0px 2px;
          }
        }
      }
      .blockInfo-text:hover {
        font-size: 108px;
      }
      a {
        text-decoration: none;
      }
      .router-link-active {
        text-decoration: none;
      }
    }
    .blockInfoBox-item1 {
      width: 500px;
      margin-right: 10px;
      background: url("../../../assets/home/item1.png") no-repeat;
      background-size: 100% 100%;
    }
    .blockInfoBox-item2 {
      width: 340px;
      margin-right: 10px;
      background: url("../../../assets/home/item3.png") no-repeat;
      background-size: 100% 100%;
    }
    .blockInfoBox-item3 {
      width: 340px;
      margin-right: 10px;
      background: url("../../../assets/home/item3.png") no-repeat;
      background-size: 100% 100%;
    }
    .blockInfoBox-item4 {
      width: 340px;
      margin-right: 10px;
      background: url("../../../assets/home/item3.png") no-repeat;
      background-size: 100% 100%;
    }
    .blockInfoBox-item5 {
      width: 340px;
      margin-right: 10px;
      background: url("../../../assets/home/item3.png") no-repeat;
      background-size: 100% 100%;
    }
  }
}
</style>
