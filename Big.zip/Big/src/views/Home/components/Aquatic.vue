<template>
  <div>
    <el-dialog
      v-model="dialogVisible"
      title="水生生物"
      :show-close="false"
      width="45%"
    >
      <div class="btn_exit">
        <img
          src="../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="width: 0.13rem; float: right; margin-top: -0.23rem; cursor:pointer;"
        />
      </div>
      <div>
        <img
          src="../../../common/picture/800.jpeg"
          alt=""
          style="width: 4.4rem; height: 3rem; margin-top: 0"
        />
      </div>
      <div style="margin-top: 0.03rem; margin-left: 0.4rem; text-align: center">
        <div style="float: left; margin-left: -0.2rem">
          <span id="Aquatic_series">历年平均</span>
        </div>
        <span id="Aquatic_name" style="font-fanily: 'FZMWFont'"
          >浮游植物</span
        >
        <div style="float: right; margin-right: 0.2rem">
          数量：<span id="Aquatic_number">753</span>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
  <div id="aquatic" style="width: 100%; height: 0.9rem" v-if="isShowEcharts"></div>
</template>

<script>
import * as echarts from "echarts";
import { ref, onUnmounted } from "vue";

export default {
  name: "Aquatic",
  setup(){
    let isShowEcharts = ref(true);

    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    return{
      isShowEcharts,
    };
  },
  data() {
    const dialogVisible = ref(false);
    return { dialogVisible };
  },
  mounted() {
    var myChart = echarts.init(document.getElementById("aquatic"));
    var option = {
      title: {
        subtext: "单位：种",
        subtextStyle: {
          color: "#EDEAEA",
          fontSize: "0.07rem",
          fontFamily: "Microsoft YaHei",
          align: "right",
          fontWeight: 400,
        },
        right: "10%",
        // textAlign: 'right'
      },
      backgroundColor: "transparent",
      legend: {
        show: true,
        textStyle: {
          fontSize: "0.065rem",
          fontWeight: 400,
          color: "white",
        },
        // left: "70%",
        // top: "-5%",
        // bottom: "10%",
        // // // formatter: '{name}:{value}',
        // // formatter: function (name,value) {
        // //   return name + value;
        // // },
        // textStyle: {
        //   fontSize: '0.065rem',
        //   fontWeight: 400,
        //   color: "white",
        // },
        // top: "bottom",
      },
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow",
        },
      },
      grid: {
        left: "5%",
        right: "5%",
        top: "20%",
        bottom: "10px",
        containLabel: true,
      },
      xAxis: {
        type: "category",
        data: [ "浮游植物", "大型无脊椎\n动物", "鱼类", "浮游动物", "水生植物", "哺乳动物"],
        axisLine: {
          show: true,
        },
        axisTick: {
          show: false,
        },
        axisLabel: {
          fontSize: "0.068rem",
          fontFamily: "Microsoft YaHei",
          interval: 0,
          color: "#fff",
        },
      },
      yAxis: {
        type: "value",
        splitLine: {
          show: false,
        },
        axisLine: {
          show: true,
        },
        axisTick: {
          show: false,
        },
        axisLabel: {
          fontSize: "0.06rem",
          fontFamily: "Microsoft YaHei",
          color: "#fff",
        },
      },
      color: [
        "#09326D",
        {
          type: "linear",
          x: 0,
          y: 0,
          x2: 1,
          y2: 0,
          colorStops: [
            {
              offset: 1,
              color: "#FF7AF5", // 0% 处的颜色
            },
            {
              offset: 0,
              color: "#754080", // 100% 处的颜色
            },
          ],
          global: false, // 缺省为 false
        },
        {
          type: "linear",
          x: 0,
          y: 0,
          x2: 1,
          y2: 0,
          colorStops: [
            {
              offset: 1,
              color: "#E6FC11", // 0% 处的颜色
            },
            {
              offset: 0,
              color: "#6DD6D9", // 100% 处的颜色
            },
          ],
          global: false, // 缺省为 false
        },
      ],
      series: [
        {
          name: "历年平均",
          type: "bar",
          barWidth: "30%",
          itemStyle: {
            // color: '#09326D',
            borderWidth: 1,
            borderColor: "#00CCFF",
          },
          data: [753, 357, 200, 465, 252, 1],
        },
        {
          name: "2020",
          type: "line",
          smooth: true,
          itemStyle: {
            color: "#F23C3C",
            show: true,
          },
          color: "#F23C3C",
          data: [800, 320, 108, 666, 190, 1],
        },
        {
          name: "2021",
          type: "line",
          smooth: true,
          color: "#FFCF18",
          itemStyle: {
            borderCap: "round",
            color: "#FFCF18",
            decal: {
              symbol: "roundRect",
            },
          },
          data: [650, 366, 192, 512, 333, 1],
        },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
    // myChart.on("click", function (params) {
    //   // 在用户点击后控制台打印数据的名称
    //   console.log(params);
    // });
    myChart.on("click", this.nav_open);
    myChart.on("click", function (param) {
      // console.log(param.name);
      const aquaticName = param.name;
      const aquaticNumber = param.value;
      const aquaticSeries = param.seriesName;
      // console.log(BirdName);
      document.getElementById("Aquatic_series").innerHTML = aquaticSeries;
      document.getElementById("Aquatic_name").innerHTML = aquaticName;
      document.getElementById("Aquatic_number").innerHTML = aquaticNumber;
    });
  },
  methods: {
    nav_open() {
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 3.04rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
</style>
