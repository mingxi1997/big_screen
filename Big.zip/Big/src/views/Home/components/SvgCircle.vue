<template>
  <circle class="progress" r="128px" cy="148px" cx="148" stroke-width="18" stroke="#2B23D4" stroke-linejoin="round" stroke-linecap="round" fill="none" stroke-dashoffset="0"  stroke-dasharray="601px" />
  <circle class="progress1" r="108px" cy="148px" cx="148" stroke-width="18" stroke="#23D472" stroke-linejoin="round" stroke-linecap="round" fill="none" stroke-dashoffset="0"  stroke-dasharray="470px" />
  <circle class="progress" r="88px" cy="148px" cx="148" stroke-width="18" stroke="#D47623" stroke-linejoin="round" stroke-linecap="round" fill="none" stroke-dashoffset="0"  stroke-dasharray="320px" />
  <circle class="progress1" r="68px" cy="148px" cx="148" stroke-width="18" stroke="#5E1DE3" stroke-linejoin="round" stroke-linecap="round" fill="none" stroke-dashoffset="0"  stroke-dasharray="321px" />
  <circle class="progress" r="48px" cy="148px" cx="148" stroke-width="18" stroke="#5B83CD" stroke-linejoin="round" stroke-linecap="round" fill="none" stroke-dashoffset="0"  stroke-dasharray="210px" />
  <circle class="progress1" r="28px" cy="148px" cx="148" stroke-width="18" stroke="#8C8C8F" stroke-linejoin="round" stroke-linecap="round" fill="none" stroke-dashoffset="0"  stroke-dasharray="135px" />
</template>

<script>
export default {
  name: 'svgCircle'
}
</script>

<style scoped>
.progress {
  animation: rotate 1500ms linear both;
}
.progress1 {
  animation: rotate1 1500ms linear both;
}
@keyframes rotate {
  from {
    stroke-dashoffset: 471px;
  }
  to {
    stroke-dashoffset: 0px;
  }
}
@keyframes rotate1 {
  from {
    stroke-dashoffset: 371px;
  }
  to {
    stroke-dashoffset: 0px;
  }
}
</style>
