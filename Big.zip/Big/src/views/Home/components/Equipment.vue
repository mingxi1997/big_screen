<template>
  <div class="equipmentBox">
    <router-link to="/infraredmain">
      <div class="equipment-1">
        <div class="text">{{infrared}}</div>
        <div class="title">红外相机</div>
      </div></router-link
    >
    <router-link to="/weathermain">
      <div class="equipment-2">
        <div class="text">{{weather}}</div>
        <div class="title">气象站</div>
      </div></router-link
    >
    <router-link to="/aimain">
      <div class="equipment-3">
        <div class="text">{{ai}}</div>
        <div class="title">AI监测站</div>
      </div></router-link
    >
    <router-link to="/towermain">
      <div class="equipment-4">
        <div class="text">{{tower}}</div>
        <div class="title">塔吊</div>
      </div></router-link
    >
  </div>
</template>

<script>
import URL from '@/api/baseUrl'
export default {
  name: "Equipment",
  components: {},
  props: [],
  emits: [],
  setup() {
    return {};
  },
  data() {
    var infrared, weather, ai, tower;
    return {
      infrared,
      weather,
      ai, 
      tower,
    };
  },
  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/equip/name`).then((res) => {
        // console.log(res.data);
        this.infrared = res.data.equip.infrared.total;
        this.weather = res.data.equip.weather.total;
        this.ai = res.data.equip.ai.total;
        this.tower = res.data.equip.tower.total;
      });
    },
  },
  created(name) {
    this.query_data(name);
  },
};
</script>

<style lang="less" scoped>
a {
  text-decoration: none;
}
.router-link-active {
  text-decoration: none;
}
.equipmentBox {
  width: 858px;
  height: 300px;
  .equipment-1,
  .equipment-2,
  .equipment-3,
  .equipment-4 {
    display: inline-block;
    vertical-align: top;
    width: 25%;
    height: 100%;
    margin-top: 3%;
    text-align: center;
    a {
      text-decoration: none;
    }
    .router-link-active {
      text-decoration: none;
    }
    .text {
      height: 165px;
      line-height: 165px;
      color: #ffb54c;
      font-weight: bold;
      font-size: 66px;
      text-shadow: #ffb54c 0px 0px 30px;
    }
    .title {
      font-size: 33px;
      color: white;
      a {
        text-decoration: none;
      }
    }
  }
  .equipment-1:hover,
  .equipment-2:hover,
  .equipment-3:hover,
  .equipment-4:hover {
    background: rgba(120, 120, 180, 0.4);
    height: 85%;
  }
  .equipment-1:active,
  .equipment-2:active,
  .equipment-3:active,
  .equipment-4:active {
    background: rgba(120, 120, 180, 0.6);
    height: 85%;
  }
}
</style>
