<template>
  <div class="titlebox">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'MyTitle',
  components: {}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.titlebox {
  width: 858px;
  height: 63px;
  font-size: 40px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  background: url('../../../assets/home/mytitlebg.png') no-repeat;
  background-position: bottom;
  background-size: 100% 35px;
}
</style>
