<template>
  <div class="box" @mouseenter="setMouseOver" @mouseleave="setMouseOut">
    <div class="backBtn" @click="back">返回</div>
    <div class="chart-wrapper" ref="scatterMap"></div>
  </div>
</template>
<script>
// import http from '@/api/template.js'
import * as echarts from 'echarts'
import { debounce, getGeoJson, getMapInfo } from '@/utils/index.js'
import http from '../../api/footpath'
import { onMounted, onBeforeUnmount, ref, reactive, computed, watch } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'mapChina',
  setup () {
    const store = useStore()
    const abcode = computed(() => mapInfo[mapInfo.length - 1].code)
    const mapInfo = reactive([
      {
        cityName: '全国',
        code: 100000
      }
    ])
    let myChart = null
    const geoJson = ref(null)
    const scatterMap = ref(null)
    const mapInfoindex = ref(1)
    const resizeHandler = debounce(() => {
      if (myChart) {
        myChart.resize()
      }
    }, 200)

    onMounted(() => {
      getMapJson()
      window.addEventListener('resize', resizeHandler)
    })
    onBeforeUnmount(() => {
      window.removeEventListener('resize', resizeHandler)
    })

    // 通过高德获取geoJson数据
    function getMapJson () {
      getGeoJson(abcode.value, geoJson.value).then((result) => {
        if (geoJson.value && !result.features.length) {
          back()
          return
        }
        geoJson.value = result
        store.dispatch('footpath/setabcode', abcode.value)
        getMapData()
      }).catch((err) => {
        console.log(err)
      })
    }

    // 模拟接口，获取echarts数据
    function getMapData () {
      getMapInfo(abcode.value).then((data) => {
        http.getRegion({
          abcode: abcode.value
        }).then((res) => {
          const mapData = data.map(item => {
            for (let i = 0; i < res.data.length; i++) {
              if (item.adcode === res.data[i].regionCode && res.data[i].trailNum > 0) {
                return {
                  itemStyle: {
                    areaColor: '#3AC04CFF',
                    shadowColor: 'rgb(58,192,103)'
                  },
                  ...item,
                  value: res.data[i].trailNum
                }
              }
            }
            return {
              name: item.name,
              value: 0,
              adcode: item.adcode
            }
          })
          console.log(mapData)
          initEcharts(mapData)
        })
      }).catch((err) => {
        console.log(err)
      })
    }

    // 渲染echarts图
    const initEcharts = data => {
      myChart = echarts.init(scatterMap.value || scatterMap)

      if (mapInfo.length === 1) {
        echarts.registerMap('china', geoJson.value) // 注册
      } else {
        echarts.registerMap('map', geoJson.value) // 注册
      }
      myChart.setOption(
        {
          baseOption: {
            animation: true,
            animationDuration: 900,
            animationEasing: 'cubicInOut',
            animationDurationUpdate: 900,
            animationEasingUpdate: 'cubicInOut',

            title: {
              left: 'center',
              top: 0,
              text: mapInfo[mapInfo.length - 1].cityName + '智慧步道统计图',
              textStyle: {
                // color: 'rgb(179, 239, 255)',
                color: '#00CCFF',
                fontSize: '20px'
              }
            },
            tooltip: {
              trigger: 'item',
              formatter: p => {
                let val = p.value
                if (p.name === '南海诸岛') return
                if (window.isNaN(val)) {
                  val = 0
                }
                const txtCon =
                  '<div style=\'text-align:left\'>' +
                  p.name +
                  val +
                  '</div>'
                // const txtCon =
                //   "<div style='text-align:left'>" +
                //   p.name +
                //   ':<br />销售额：' +
                //   val.toFixed(2) +
                //   '万</div>'
                return txtCon
              }
            },
            series: [
              {
                name: '销售额度',
                type: 'map',
                map: mapInfo.length === 1 ? 'china' : 'map',
                roam: true,
                // zoom: 1.25,
                zoom: mapInfo.length === 1 ? 1.5 : 1.1,
                center: mapInfo.length === 1 ? [110, 35] : '',
                itemStyle: {
                  areaColor: '#1a57af',
                  borderColor: '#fff',
                  borderWidth: 2,
                  shadowBlur: 15,
                  shadowColor: 'rgb(58,115,192)',
                  shadowOffsetX: 7,
                  shadowOffsetY: 6
                },
                label: {
                  show: false,
                  color: 'rgb(249, 249, 249)', // 省份标签字体颜色
                  formatter: p => {
                    switch (p.name) {
                      case '内蒙古自治区':
                        p.name = '内蒙古'
                        break
                      case '西藏自治区':
                        p.name = '西藏'
                        break
                      case '新疆维吾尔自治区':
                        p.name = '新疆'
                        break
                      case '宁夏回族自治区':
                        p.name = '宁夏'
                        break
                      case '广西壮族自治区':
                        p.name = '广西'
                        break
                      case '香港特别行政区':
                        p.name = '香港'
                        break
                      case '澳门特别行政区':
                        p.name = '澳门'
                        break
                      default:
                        break
                    }
                    return p.name
                  }
                },
                emphasis: {
                  label: {
                    show: true,
                    color: '#f75a00',
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: '#ababab',
                    borderRadius: 4,
                    padding: [2, 3]
                  },
                  areaColor: '#fcb74e',
                  borderWidth: 2,
                  shadowBlur: 25
                },
                data: data
              }
            ]
          }
        },
        true
      )

      myChart.off('click')
      myChart.on('click', function (params) {
        if (params.dataIndex && mapInfoindex.value < 3) {
          const index = params.dataIndex
          if (data[index]) {
            if (mapInfo[mapInfo.length - 1].code === data[index].adcode) {
              return
            }
            mapInfo.push({
              cityName: data[index].name,
              code: data[index].adcode
            })
            mapInfoindex.value++
          }
        }
      })
    }

    function back () {
      if (mapInfo.length === 1 || mapInfoindex.value < 2) {
        return
      }
      mapInfo.splice(mapInfo.length - 1)
      mapInfoindex.value--
    }

    watch(
      abcode,
      () => {
        getMapJson()
      },
      {
        lazy: false,
        deep: true
      }
    )

    return {
      scatterMap,
      back
    }
  }
}
</script>

<style scoped>
.box {
  width: 100%;
  height: 100%;
  position: relative;
}

.backBtn {
  position: absolute;
  left: 0px;
  bottom: 0px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  color: #fff;
  background: #5e9ed5;
  /* background: rgb(94, 158, 213, 0.4); */
  overflow: hidden;
  text-align: center;
  line-height: 50px;
  z-index: 99999999999;
}

.backBtn:hover {
  cursor: pointer;
}

.chart-wrapper {
  width: calc(100% - 20px);
  height: 100%;
}
</style>
