<template>
  <div class="mapBox">
    <div class="lefttop"></div>
    <div class="leftbottom"></div>
    <div class="righttop"></div>
    <div class="rightbottom"></div>
    <div class="container" id="container"  style="height: 100%;"></div>
    <div class="info">
      <div class="info-title">江苏省环保厅</div>
      <div class="info-icon1">已建成站点</div>
      <div class="info-icon2">未建成站点</div>
    </div>
  </div>
</template>

<script>
import map from '@/utils/map'
export default {
  name: 'Map',
  components: {},
  props: [],
  emits: [],
  setup (props, context) {
    map.mapUI('63df70c525f9ac6d0e1d4c394076aac6').then(AMap => {
      const opts = {
        subdistrict: 0,
        extensions: 'all',
        level: 'province'
      }
      // 利用行政区查询获取边界构建mask路径
      // 也可以直接通过经纬度构建mask路径
      const district = new AMap.DistrictSearch(opts)
      district.search('江苏省', function (status, result) {
        const bounds = result.districtList[0].boundaries
        const polygons = []
        // for (let i = 0, l = bounds.length; i < l; i++) {
        //   // 生成行政区划polygon
        //   let polygon = new AMap.Polygon({
        //     strokeWeight: 20,
        //     path: bounds[i],
        //     fillOpacity: 0.4,
        //     fillColor: '#80d8ff',
        //     strokeColor: '#0091ea'
        //   })
        //   polygons.push(polygon)
        // }
        const mask = []
        for (let i = 0; i < bounds.length; i += 1) {
          mask.push([bounds[i]])
        }
        const map = new AMap.Map('container', {
          // mask: mask,
          resizeEnable: true,
          mapStyle: 'amap://styles/4823118b1afc7fd39cb81646cd5675c7',
          // labelzIndex: 130,
          pitch: 20,
          zoom: 9
        })
        map.add(polygons)
        // 添加描边
        for (var i = 0; i < bounds.length; i += 1) {
          new AMap.Polyline({
            path: bounds[i],
            strokeColor: '#99ffff',
            strokeWeight: 5,
            map: map
          })
        }
        const disWorld = new AMap.DistrictLayer.Province({
          zIndex: 12,
          adcode: [320000],
          depth: 2,
          styles: {
            'fill': '#08285A',
            'province-stroke': 'cornflowerblue',
            'city-stroke': '#3F67A5', // 中国地级市边界
            'stroke-weight': 5, // 中国地级市边界
            'county-stroke': 'red' // 中国区县边界
          }
        })
        disWorld.setMap(map)
        // 添加呼吸点
        const loca = new Loca.Container({
          map
        })
        // 蓝色普通点
        const geo = new Loca.GeoJSONSource({
          url: 'https://a.amap.com/Loca/static/loca-v2/demos/mock_data/sz_road.json',
        })
        const scatter = new Loca.ScatterLayer({
          zIndex: 111,
          opacity: 1,
          visible: true,
          zooms: [2, 22]
        })
        scatter.setSource(geo)
        scatter.setStyle({
          color: 'rgba(43,156,75,1)',
          unit: 'meter',
          size: [150, 150],
          borderWidth: 0
        })
        loca.add(scatter)

        // 红色呼吸点
        const geoLevelF = new Loca.GeoJSONSource({
          // data: [],
          url: 'https://a.amap.com/Loca/static/loca-v2/demos/mock_data/sz_road_F.json',
        })
        const breathRed = new Loca.ScatterLayer({
          loca,
          zIndex: 113,
          opacity: 1,
          visible: true,
          zooms: [2, 22]
        })
        breathRed.setSource(geoLevelF)
        breathRed.setStyle({
          unit: 'meter',
          size: [2600, 2600],
          borderWidth: 0,
          texture: 'https://a.amap.com/Loca/static/loca-v2/demos/images/breath_red.png',
          duration: 500,
          animate: true
        })
        map.setFitView(null, false, [150, 60, 100, 60])
      })
    })
    // 颜色辅助方法
    const colors = {}
    const getColorByAdcode = (adcode) => {
      if (!colors[adcode]) {
        var gb = Math.random() * 155 + 50
        colors[adcode] = 'rgb(' + gb + ',' + gb + ',255)'
      }

      return colors[adcode]
    }
    return {
    }
  }
}
</script>

<style lang="less" scoped>
.mapBox {
  position: relative;
  height: 1110px;
  padding: 10px 129px 78px 129px;
  box-sizing: border-box;
  .lefttop, .leftbottom, .righttop, .rightbottom {
    position: absolute;
    width: 67px;
    height: 62px;
  }
  .lefttop {
    top: 0;
    left: 119px;
    border-top: 2px solid #20DBFD;
    border-left: 2px solid #20DBFD;
  }
  .leftbottom {
    left: 119px;
    bottom: 68px;
    border-left: 2px solid #20DBFD;
    border-bottom: 2px solid #20DBFD;
  }
  .righttop {
    top: 0;
    right: 119px;
    border-top: 2px solid #20DBFD;
    border-right: 2px solid #20DBFD;
  }
  .rightbottom {
    right: 119px;
    bottom: 68px;
    border-right: 2px solid #20DBFD;
    border-bottom: 2px solid #20DBFD;
  }
  .title {
    position: absolute;
    right: 170px;
    top: 90px;
    font-size: 35px;
    font-weight: 400;
    text-align: right;
  }
  .info {
    position: absolute;
    left: 208px;
    bottom: 126px;
    width: 236px;
    height: 223px;
    background: url('../../../assets/home/kuag.png') no-repeat;
    background-size: 100% 100%;
    padding: 36px 0px 36px 23px;
    box-sizing: border-box;
    div {
      font-size: 24px;
      font-weight: 400;
      position: relative;
      &:before {
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        display: block;
        content: '';
      }
    }
    .info-title {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        width: 29px;
        height: 27px;
        background: url('../../../assets/home/huanbaoting.png') no-repeat;
        background-size: 100% 100%;
      }
    }
    .info-icon1 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #FFC13B;
        box-shadow: 0 0 20px #FFC13B;
        border-radius: 50%;
      }
    }
    .info-icon2 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #CAEEFF;
        box-shadow: 0 0 20px #CAEEFF;
        border-radius: 50%;
      }
    }
  }
  .container {
    background: transparent;
  }
}
</style>
