<template>
  <div id="Eqi" style="width: 95%; height: 0.8rem" v-if="isShowEcharts"></div>
</template>

<script>
import * as echarts from "echarts";
import { ref, onUnmounted } from "vue";

export default {
  name: "Terrestrial",
  setup() {
    let isShowEcharts = ref(true);

    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    return {
      isShowEcharts,
    };
  },
  data() {},
  mounted() {
    var myChart = echarts.init(document.getElementById("Eqi"));
    var option = {
      title: {
        subtext: "注：此表为江苏省内EQI前10名的地区",
        subtextStyle: {
          color: "#EDEAEA",
          fontSize: "0.06rem",
          align: "right",
          fontWeight: 400,
        },
        top: "-5%",
        right: "12%",
        // textAlign: 'right'
      },
      backgroundColor: "transparent",
      tooltip: {
        trigger: "axis",
        formatter: "{a0}<br/>{b0}: {c0}",
        axisPointer: {
          type: "shadow",
        },
      },
      grid: {
        left: "-5%",
        right: "0%",
        top: "20%",
        bottom: "20px",
        containLabel: true,
      },
      xAxis: {
        type: "category",
        data: [
          "盱眙县",
          "金湖县",
          "溧阳市",
          "泗洪县",
          "宜兴市",
          "洪泽区",
          "高邮市",
          "射阳县",
          "高淳区",
          "宝应县",
        ],
        axisLine: {
          show: false,
        },
        axisTick: {
          show: false,
        },
        axisLabel: {
          fontSize: "0.06rem",
          fontFamily: "Microsoft YaHei",
          textBorderColor: "rgba(200, 243, 255, 0.8)",
          textBorderWidth: 1,
          textShadowColor: "rgba(200, 243, 255, 0.4)",
          textShadowBlur: 2,
          color: "#fff",
          interval: 0,
        },
      },
      yAxis: {
        type: "value",
        scale: true,
        min: "56",
        show: false,
      },
      colorBy: [
        "#FFCCCC",
        "#CCFFFF",
        "#FFFFCC",
        "#CCCCFF",
        "#FF9966",
        "#CCFF99",
        "#99CCFF",
        "#FFCC99",
        "#99CC99",
        "#6699CC",
        "#CCCCCC",
      ],
      series: [
        {
          name: "2011",
          type: "bar",
          barWidth: "45%", // 柱的宽度
          itemStyle: {
            opacity: 0.8,
            shadowColor: "#ecf390",
            shadowBlur: 4,
          },
          label: {
            show: true,
            fontSize: "0.08rem",
            position: "top",
            color: "rgb(255, 255, 255)",
            textBorderColor: "rgba(200, 243, 255, 0.8)",
            textBorderWidth: 1,
            textShadowColor: "rgba(200, 243, 255, 0.6)",
            textShadowBlur: 3,
            opacity: 1,
          },
          data: [65.6, 65.3, 64.0, 63.3, 63.2, 62.0, 61.1, 60.7, 60.2, 59.6],
        },
        {
          type: "line",
          lineStyle: {
            show: false,
            opacity: 0,
          },
          itemStyle: {
            color: "white",
            borderColor: "white",
            borderWidth: 2,
            shadowColor: "white",
            shadowBlur: 10,
          },
          label: {
            show: false,
            fontSize: "0.08rem",
            position: "top",
            color: "rgb(255, 255, 255)",
            opacity: 1,
          },
          data: [65.6, 65.3, 64.0, 63.3, 63.2, 62.0, 61.1, 60.7, 60.2, 59.6],
        },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
  },
  methods: {},
};
</script>

<style lang="less" scoped>
#Eqi:hover {
  background: rgba(120, 120, 180, 0.4);
  height: 90%;
}
#Eqi:active {
  background: rgba(120, 120, 180, 0.6);
}
</style>
