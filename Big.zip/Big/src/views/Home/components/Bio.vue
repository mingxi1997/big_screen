<template>
  <div class="botanyBox">
    <div class="botany-itemBox" id="1">
      <router-link to="/bio">
        <div class="botany-item botany-item1">
          <div class="botany-title">{{ total }}<span>种</span></div>
          <div class="botany-text">全部物种</div>
        </div>
      </router-link>
    </div>
    <div class="botany-itemBox" id="2">
      <router-link to="/endangered">
        <div class="botany-item botany-item2">
          <div class="botany-title">{{ endangered }}<span>种</span></div>
          <div class="botany-text">濒危物种</div>
        </div>
      </router-link>
    </div>
    <div class="botany-itemBox" id="3">
      <router-link to="/invade">
        <div class="botany-item botany-item3">
          <div class="botany-title">{{ invade }}<span>种</span></div>
          <div class="botany-text">入侵物种</div>
        </div>
      </router-link>
    </div>
    <div class="botany-itemBox" id="4">
      <router-link to="/invest">
        <div class="botany-item botany-item4">
          <div class="botany-title">{{ invest }}<span>种</span></div>
          <div class="botany-text">调查物种</div>
        </div>
      </router-link>
    </div>
  </div>
</template>

<script>
import { useRouter } from "vue-router";
import URL from '@/api/baseUrl'

export default {
  name: "Bio",
  components: {},
  props: [],
  emits: [],
  setup(props, context) {
    return {};
  },
  data() {
    var total, endangered, invade, invest;
    return {
      total,
      endangered,
      invade,
      invest,
    };
  },
  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/bio/name`).then((res) => {
        console.log(res.data);
        this.total = res.data.bio.total;
        this.endangered = res.data.bio.endangered;
        this.invade = res.data.bio.invade;
        this.invest = res.data.bio.invest;
      });
    },
  },
  created(name) {
    this.query_data(name);
  },
};
</script>

<style lang="less" scoped>
a {
  text-decoration: none;
}
.router-link-active {
  text-decoration: none;
}
.botanyBox {
  width: 100%;
  height: 250px;
  .botany-itemBox {
    width: 23.5%;
    height: 100%;
    display: inline-block;
    vertical-align: top;
    padding-top: 30px;
    box-sizing: border-box;
    .botany-item {
      margin: 0 auto;
      width: 180px;
      height: 180px;
      text-align: center;
      .botany-title {
        height: 93px;
        line-height: 120px;
        position: relative;
        font-size: 44px;
        font-weight: bold;
        font-style: italic;

        span {
          font-size: 20px;
        }
        &:before {
          position: absolute;
          content: "";
          bottom: 0;
          left: 50%;
          transform: translate(-50%, -50%);
          background: #3ccae8;
          width: 119px;
          height: 1px;
        }
      }
      .botany-text {
        font-size: 25px;
        font-weight: 400;
        color: #3ccae8;
        height: 91px;
        line-height: 60px;
      }
    }
    .botany-item1 {
      background: url("../../../assets/home/green.png") no-repeat;
      background-size: 100% 100%;
      color: #20ec8b;
      // animation: dorotate 3s ease-in-out infinite;
      // animation-timing-function: linear;
    }
    .botany-item2 {
      background: url("../../../assets/home/red.png") no-repeat;
      background-size: 100% 100%;
      color: #ff6161;
      // animation: dorotate 3s ease-in-out infinite;
      // animation-timing-function: linear;
    }
    .botany-item3 {
      background: url("../../../assets/home/grape.png") no-repeat;
      background-size: 100% 100%;
      color: #bc6dff;
      // animation: dorotate 3s ease-in-out infinite;
      // animation-timing-function: linear;
    }
    .botany-item4 {
      background: url("../../../assets/home/blue.png") no-repeat;
      background-size: 100% 100%;
      color: #3acedc;
      //   animation: dorotate 3s ease-in-out infinite;
      //   animation-timing-function: linear;
      // }
      // @keyframes dorotate {
      //   from {
      //     transform: rotate(0deg);
      //   }
      //   to {
      //     transform: rotate(360deg);
      //   }
    }
  }
  .botany-itemBox:hover {
    background: rgba(120, 120, 180, 0.4);
  }
  .botany-itemBox:active {
    background: rgba(120, 120, 180, 0.6);
  }
}
</style>
