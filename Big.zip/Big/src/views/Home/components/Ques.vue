<template>
  <div class="questionBox">
    <div class="question-itemBox">
        <div class="question-title">需整改问题：</div>
        <div class="question-text">{{ num }}</div>
      </div>
  </div>
</template>

<script>
import URL from '@/api/baseUrl'
export default {
  name: "Question",
  components: {},
  props: [],
  emits: [],
  setup(props, context) {
    return {};
  },
  data() {
    var num;
    return { num, };
  },
  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/ques/name`).then((res) => {
        // console.log(res.data);
        this.num = res.data.total;
      });
    },
  },
  created(name) {
    this.query_data(name);
  },
};
</script>

<style lang="less" scoped>
.questionBox {
  width: 100%;
  height: 170px;
  color: white;
  .question-itemBox {
    width: 95%;
    height: 100%;
    display: inline-block;
    vertical-align: top;
    box-sizing: border-box;
    .question-title {
      float: left;
      padding-top: 1%;
      padding-left: 20%;
      height: 1px;
      line-height: 160px;
      position: relative;
      font-size: 49px;
      font-weight: bold;
      font-style: italic;
    }
    .question-text {
      float: left;
      padding-top: 1.5%;
      padding-left: 18%;
      color: #ffb54c;
      font-weight: bold;
      font-size: 80px;
      text-shadow: #ffb54c 0px 0px 30px;
      line-height: 160px;
    }
  }
  .question-itemBox:hover {
    background: rgba(120, 120, 180, 0.4);
  }
  .question-itemBox:active {
    background: rgba(120, 120, 180, 0.6);
  }
}
</style>
