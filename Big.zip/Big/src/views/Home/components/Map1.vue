<template>
  <div class="mapBox">
    <div class="lefttop"></div>
    <div class="leftbottom"></div>
    <div class="righttop"></div>
    <div class="rightbottom"></div>
<!--    <div id="container" ></div>-->
    <div class="chart-wrapper" ref="scatterMap" style="height: 100%"></div>
    <div class="info">
      <div class="info-title">江苏省环保厅</div>
      <div class="info-icon1">已建成站点</div>
      <div class="info-icon2">未建成站点</div>
    </div>
  </div>
</template>

<script>
import map from '@/utils/map'
import * as echarts from 'echarts'
import { debounce } from '@/utils/index.js'
import { onBeforeUnmount, onMounted, reactive, ref } from 'vue'
export default {
  name: 'Map',
  components: {},
  props: [],
  emits: [],
  setup (props, context) {
    const scatterMap = ref(null)
    let myChart = null
    const mapJson = {
      features: null
    }
    const mapInfo = reactive([
      {
        cityName: '全国',
        code: 100000
      }
    ])
    // 渲染echarts图
    const initEcharts = data => {
      myChart = echarts.init(scatterMap.value || scatterMap)
      echarts.registerMap('map', mapJson) // 注册

      myChart.setOption(
        {
          baseOption: {
            animation: true,
            animationDuration: 900,
            animationEasing: 'cubicInOut',
            animationDurationUpdate: 900,
            animationEasingUpdate: 'cubicInOut',

            title: {
              left: 'center',
              top: 0,
              text: mapInfo[mapInfo.length - 1].cityName + 'xxx',
              textStyle: {
                // color: 'rgb(179, 239, 255)',
                color: '#00CCFF',
                fontSize: '20px'
              }
            },
            series: [
              {
                name: '销售额度',
                type: 'map',
                map: 'map',
                roam: true,
                zoom: 1.25,
                itemStyle: {
                  areaColor: '#08285A',
                  borderColor: '#3F67A5',
                  borderWidth: 5,
                  shadowBlur: 10
                },
                label: {
                  show: false,
                  color: 'rgb(249, 249, 249)' // 省份标签字体颜色
                },
                emphasis: {
                  show: false,
                  label: {
                    show: false,
                    color: '#f75a00',
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: '#3F67A5',
                    borderRadius: 4,
                    padding: [2, 3]
                  },
                  areaColor: '#08285A',
                  borderWidth: 2,
                  shadowBlur: 25
                },
                data: data
              },
            ]
          }
        },
        true
      )
      // myChart.off('click')
      // myChart.on('click', function (params) {
      //   // const index = params.dataIndex
      //   // console.log(data[index].adcode)
      //   myChart.resize()
      // })
    }
    onMounted(() => {
      map.mapUI('a804ac2fd8686d29e60aac5748d4a503').then(AMap => {
        // const mymap = new AMap.Map('container', {
        //   resizeEnable: true,
        //   zoom: 11, // 级别
        //   mapStyle: 'amap://styles/fresh'
        //   // viewMode: '3D' // 使用3D视图
        // })
        const adcode = 320000 // 全国的区划编码
        AMapUI.loadUI(['geo/DistrictExplorer'], (DistrictExplorer) => {
          const districtExplorer = new DistrictExplorer()
          // 清除已有的绘制内容
          // districtExplorer.clearFeaturePolygons()
          districtExplorer.loadAreaNode(adcode, function (error, areaNode) {
            if (error) {
              console.log('地图展示失败')
              return
            }
            const Json = areaNode.getSubFeatures()
            mapJson.features = Json
            const district = new AMap.DistrictSearch()
            district.search(adcode, function (status, result) {
              if (status !== 'complete') {
                console.log('获取地图数据失败')
                return
              }
              const data = result.districtList[0]
              if (
                (data.level === 'district' &&
                  data.districtList[0].level === 'street') ||
                !data.districtList
              ) {
                initEcharts([data])
                return
              }
              initEcharts(data.districtList)
            })
          })
        })
      })
    })
    return {
      scatterMap
    }
  }
}
</script>

<style lang="less" scoped>
.mapBox {
  position: relative;
  height: 1110px;
  padding: 10px 129px 78px 129px;
  box-sizing: border-box;
  .lefttop, .leftbottom, .righttop, .rightbottom {
    position: absolute;
    width: 67px;
    height: 62px;
  }
  .lefttop {
    top: 0;
    left: 119px;
    border-top: 2px solid #20DBFD;
    border-left: 2px solid #20DBFD;
  }
  .leftbottom {
    left: 119px;
    bottom: 68px;
    border-left: 2px solid #20DBFD;
    border-bottom: 2px solid #20DBFD;
  }
  .righttop {
    top: 0;
    right: 119px;
    border-top: 2px solid #20DBFD;
    border-right: 2px solid #20DBFD;
  }
  .rightbottom {
    right: 119px;
    bottom: 68px;
    border-right: 2px solid #20DBFD;
    border-bottom: 2px solid #20DBFD;
  }
  .title {
    position: absolute;
    right: 170px;
    top: 90px;
    font-size: 35px;
    font-weight: 400;
    text-align: right;
  }
  .info {
    position: absolute;
    left: 208px;
    bottom: 126px;
    width: 236px;
    height: 223px;
    background: url('../../../assets/home/kuag.png') no-repeat;
    background-size: 100% 100%;
    padding: 36px 0px 36px 23px;
    box-sizing: border-box;
    div {
      font-size: 24px;
      font-weight: 400;
      position: relative;
      &:before {
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        display: block;
        content: '';
      }
    }
    .info-title {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        width: 29px;
        height: 27px;
        background: url('../../../assets/home/huanbaoting.png') no-repeat;
        background-size: 100% 100%;
      }
    }
    .info-icon1 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #FFC13B;
        box-shadow: 0 0 20px #FFC13B;
        border-radius: 50%;
      }
    }
    .info-icon2 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #CAEEFF;
        box-shadow: 0 0 20px #CAEEFF;
        border-radius: 50%;
      }
    }
  }
}
</style>
