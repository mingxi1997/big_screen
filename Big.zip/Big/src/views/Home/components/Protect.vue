<template>
  <div class="protectBox">
    <div class="item" @click="onChoose(index)" @mouseover="onSelect(index)" :class="{'action': index === action}" v-for="(item, index) in list" :key="index"><div>{{ item }}</div></div>
  </div>
</template>

<script>
import { useRouter } from "vue-router";
import { ref } from 'vue'

export default {
  name: 'Protect',
  setup () {
    const router = useRouter();
    window.doUrl = () => {
      router.push("/substation");
    };
    const action = ref(0)
    const list = ref([
      '南京沿江湿地综合观测站',
      '镇江长江豚类保护湿地观测样区',
      '扬州三江营湿地观测样区',
      '泰州沿江重要湿地观测样区',
      '南通长江口北支湿地观测样区',
      '太湖湖泊湿地',
      '泗洪洪泽湖湿地',
      '苏州西山岛',
      '泰州兴化里下河湿地',
      '宿迁骆马湖湿地',
      '盐城滨海湿地',
      '大丰麋鹿保护湿地',
      '盐城条子泥湿地',
      '连云港临洪河口湿地',
      '宜兴龙池山森林',
      '常州天目山森林',
      '南京老山森林',
      '盱眙铁山寺森林',
      '徐州大洞山森林',
      '连云港云台山森林'
    ])
    const onChoose = (index) => {
       action.value = index;
       doUrl();
    }
    const onSelect = (index) => {
       action.value = index;
      //  doUrl();
      // if (value.length > 5 && value.length < 14) {
      //         return value.slice(0, 6) + '' + value.slice(6)
      //       } else {
      //         return value
      //       }
    }
    return {
      list,
      action,
      onChoose,
      onSelect
    }
  }
}
</script>

<style lang="less" scoped>
.protectBox {
  width: 100%;
  height: 536px;
  padding-top: 80px;
  box-sizing: border-box;
  font-weight: 200;
  color: rgba(255, 255, 255, 0.9);
  .item {
    width: 300px;
    height: 120px;
    margin-left: 8%;
    margin-bottom: 20px;
    padding-left: 0.04rem;
    padding-right: 0.04rem;
    font-size: 0.075rem;
    letter-spacing: 0.005rem;
    line-height: 0.11rem;
    background: url('../../../assets/home/btnbg.png') no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    vertical-align: top;
    cursor: pointer;
    div {
      width: 100%;
      height: 100%;
      padding: 10px;
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      text-align: center;
    }
  }
  .action {
    background-image: url('../../../assets/home/btnbg-a.png') !important;
  }
}
</style>
