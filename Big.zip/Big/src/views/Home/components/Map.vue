<template>
  <div class="mapBox">
    <div class="lefttop"></div>
    <div class="leftbottom"></div>
    <div class="righttop"></div>
    <div class="rightbottom"></div>
    <div
      class="container"
      id="container"
      style="height: 100%; background: transparent !important"
    >
      <el-button
        circle="true"
        color="transparent"
        title="南京湿地观测站"
        style="
          height: 0.01rem;
          padding-left: 0.01rem;
          color: transparent;
          font-size: 0.06rem;
          float: center;
          position: absolute;
          margin-left: 1.783rem;
          top: 1.6rem;
          --el-button-hover-bg-color: transparent;
          --el-button-hover-border-color: transparent;
          --el-button-active-bg-color: rgba(139, 153, 158, 0.1);
          --el-button-active-border-color: transparent;
        "
        size="small"
        @mouseover.native="mouseover()"
        @click="mouseclick()"
      />
      <dv-flyline-chart-enhanced
        class="flyline_map"
        :config="config1"
        style="width: 55%; height: 98%; margin-left: 18%"
      />
    </div>
    <div class="info">
      <div class="info-title">江苏省生态环境厅</div>
      <div class="info-icon1">分站点</div>
      <div class="info-icon2">待建站点</div>
    </div>
  </div>
</template>

<script>
import { useRouter } from "vue-router";
export default {
  name: "test",
  data() {
    const config1 = {
      points: [
        {
          name: "南京站",
          coordinate: [0.37, 0.66],
          halo: {
            show: true,
            radius: 60,
          },
          icon: {
            show: true,
            src: require("@/assets/mapdatav/huanbaoting.png"),
            onclick() {
              console.log(123);
            },
          },
          text: {
            show: true,
            fontSize: 18,
          },
        },
        {
          name: "郑州",
          coordinate: [0.48, 0.35],
        },
        {
          id: "zj",
          name: "镇江",
          coordinate: [0.39, 0.62],
          // addEventListener("click",function () {
          //   alert("helloworld");
          // },
          // @click: "getMethod()"
          // onclick() {
          //   console.log(12345),
          // },
        },
        {
          name: "新乡",
          coordinate: [0.48, 0.23],
        },
        {
          name: "焦作",
          coordinate: [0.74, 0.68],
        },
        {
          name: "开封",
          coordinate: [0.59, 0.35],
        },
        {
          name: "许昌",
          coordinate: [0.53, 0.47],
        },
        {
          name: "平顶山",
          coordinate: [0.88, 0.74],
        },
        {
          name: "洛阳",
          coordinate: [0.36, 0.38],
        },
        {
          name: "周口",
          coordinate: [0.62, 0.55],
        },
        {
          name: "漯河",
          coordinate: [0.56, 0.56],
        },
        {
          name: "信阳",
          coordinate: [0.55, 0.81],
        },
        {
          name: "驻马店",
          coordinate: [0.55, 0.67],
        },
        {
          name: "济源",
          coordinate: [0.37, 0.29],
          icon: {
            show: true,
            src: require("@/assets/mapdatav/yuan 未建成.png"),
            width: 13,
          },
        },
        {
          name: "三门峡",
          coordinate: [0.2, 0.16],
        },
        {
          name: "商丘",
          coordinate: [0.76, 0.41],
        },
        {
          name: "鹤壁",
          coordinate: [0.61, 0.21],
        },
        {
          name: "濮阳",
          coordinate: [0.68, 0.87],
        },
        {
          name: "安阳",
          coordinate: [0.53, 0.1],
        },
      ],
      lines: [
        {
          source: "新乡",
          target: "南京站",
        },
        {
          source: "镇江",
          target: "南京站",
        },
        {
          source: "焦作",
          target: "南京站",
        },
        {
          source: "开封",
          target: "南京站",
        },
        {
          source: "许昌",
          target: "南京站",
        },
        {
          source: "平顶山",
          target: "南京站",
        },
        {
          source: "洛阳",
          target: "南京站",
        },
        {
          source: "周口",
          target: "南京站",
        },
        {
          source: "漯河",
          target: "南京站",
        },
        {
          source: "郑州",
          target: "南京站",
        },
        {
          source: "信阳",
          target: "南京站",
        },
        {
          source: "驻马店",
          target: "南京站",
        },
        {
          source: "济源",
          target: "南京站",
        },
        {
          source: "三门峡",
          target: "南京站",
        },
        {
          source: "商丘",
          target: "南京站",
        },
        {
          source: "鹤壁",
          target: "南京站",
        },
        {
          source: "濮阳",
          target: "南京站",
        },
        {
          source: "安阳",
          target: "南京站",
        },
      ],
      text: {
        show: true,
        fontSize: 18,
      },
      icon: {
        show: true,
        src: require("@/assets/mapdatav/yuan 已建成.png"),
        width: 13,
      },
      line: {
        color: "lightblue",
        width: 1.5,
      },
      bgImgSrc: require("@/assets/mapdatav/jiangsu.jpeg"),
      k: 1,
      ceterPointImg: {
        // onclick(){
        //   console.log(123),
        // },
      },
    };
    // var zhenj = document.getElementById("zj");
    return {
      config1,
      // zhenj,
    };
  },
  setup() {
    const router = useRouter();
    window.doUrl = () => {
      router.push("/substation");
    };
  },
  mounted() {
    // zhjen.addEventListener(
    //   "click",
    //   function () {
    //     alert("helloworld");
    //   },
    //   false
    // );
  },
  methods: {
    mouseover() {
      console.log(123456);
    },
    mouseclick() {
      console.log(321654);
      doUrl();
    },
  },
};
</script>

<style lang="less" scoped>
.mapBox {
  position: relative;
  height: 1210px;
  padding: 10px 129px 78px 129px;
  box-sizing: border-box;
  .lefttop,
  .leftbottom,
  .righttop,
  .rightbottom {
    position: absolute;
    width: 67px;
    height: 62px;
  }
  .lefttop {
    top: 0;
    left: 119px;
    border-top: 2px solid #20dbfd;
    border-left: 2px solid #20dbfd;
  }
  .leftbottom {
    left: 119px;
    bottom: 68px;
    border-left: 2px solid #20dbfd;
    border-bottom: 2px solid #20dbfd;
  }
  .righttop {
    top: 0;
    right: 119px;
    border-top: 2px solid #20dbfd;
    border-right: 2px solid #20dbfd;
  }
  .rightbottom {
    right: 119px;
    bottom: 68px;
    border-right: 2px solid #20dbfd;
    border-bottom: 2px solid #20dbfd;
  }
  .title {
    position: absolute;
    right: 170px;
    top: 90px;
    font-size: 35px;
    font-weight: 400;
    text-align: right;
  }
  .info {
    position: absolute;
    left: 208px;
    bottom: 126px;
    width: 0.9rem;
    height: 0.52rem;
    background: url("../../../assets/home/kuag.png") no-repeat;
    background-size: 100% 100%;
    padding: 0.07rem 0px 0.07rem 0.1rem;
    box-sizing: border-box;
    div {
      font-size: 0.06rem;
      font-weight: 400;
      position: relative;
      &:before {
        position: absolute;
        top: 50%;
        left: 0;
        transform: translateY(-50%);
        display: block;
        content: "";
      }
    }
    .info-title {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        width: 29px;
        height: 27px;
        background: url("../../../assets/home/huanbaoting.png") no-repeat;
        background-size: 100% 100%;
      }
    }
    .info-icon1 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #ffc13b;
        box-shadow: 0 0 20px #ffc13b;
        border-radius: 50%;
      }
    }
    .info-icon2 {
      height: 50px;
      line-height: 50px;
      text-indent: 40px;
      &:before {
        left: 4px;
        width: 19px;
        height: 19px;
        background: #caeeff;
        box-shadow: 0 0 20px #caeeff;
        border-radius: 50%;
      }
    }
  }
  .container {
    background: transparent;
    font-size: 0.07rem;
  }
  .mapTitle {
  }
}
</style>
