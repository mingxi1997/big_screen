<template>
  <div class="weatherBox">
    <div class="weatherTop">
      <div class="weather-icon">
        <img src="../../../assets/home/weather.png" alt="" />
      </div>
      <div class="weather-content">
        <div class="text">{{ weatherObj.weather }}</div>
        <div class="centigrade">{{ weatherObj.temperature }}摄氏度</div>
      </div>
      <div class="weather-address">
        <div class="text">{{ weatherObj.province + weatherObj.city }}</div>
      </div>
    </div>
    <div class="weatherInfo">
      <div class="weatherInfo-left">
        <div class="title">风向</div>
        <div class="text">{{ weatherObj.windDirection }}</div>
      </div>
      <div class="weatherInfo-content">
        <div class="title">风力</div>
        <div class="text">{{ weatherObj.windPower }}</div>
      </div>
      <div class="weatherInfo-right">
        <div class="title">湿度</div>
        <div class="text">{{ weatherObj.humidity }}%</div>
      </div>
    </div>
  </div>
</template>

<script>
import map from "@/utils/map";
import { onMounted, ref } from "vue";

export default {
  name: "Weather",
  components: {},
  props: [],
  emits: [],
  setup() {
    const weatherObj = ref({
      windDirection: "",
      temperature: "",
      humidity: "",
      windPower: "",
      weather: "",
      province: "",
      city: "",
    });
    onMounted(() => {
      setTimeout(() => {
        map.mapUI("63df70c525f9ac6d0e1d4c394076aac6").then((AMap) => {
          const citySearch = new AMap.CitySearch();
          citySearch.getLocalCity((status, result) => {
            if (status === "complete") {
              console.log(result.adcode);
              // 创建天气查询实例
              const weather = new AMap.Weather();

              // 执行实时天气信息查询
              weather.getLive(result.adcode, (err, data) => {
                console.log(err, data);
                if (!err) {
                  weatherObj.value = data;
                }
              });
            } else {
              console.log(result);
            }
          });
        });
      }, 1000);
    });
    return { weatherObj };
  },
};
</script>

<style lang="less" scoped>
.weatherBox {
  width: 100%;
  .weatherTop {
    width: 100%;
    .weather-icon,
    .weather-content,
    .weather-address {
      display: inline-block;
      vertical-align: top;
    }
    .weather-icon {
      width: 120px;
      height: 90px;
      margin-right: 40px;
      margin-bottom: 10px;
      img {
        width: 100%;
        height: 100%;
        display: block;
        box-sizing: border-box;
      }
    }
    .weather-content {
      width: 380px;
      height: 70px;
      .text {
        font-size: 40px;
        font-weight: 400;
        height: 50px;
        line-height: 61px;
        margin-right: 20px;
        margin-top: 26px;
        float: left;
      }
      .centigrade {
        font-size: 36px;
        font-weight: 400;
        color: #53c1ff;
        height: 50px;
        line-height: 50px;
        margin-top: 34px;
        float: left;
      }
    }
    .weather-address {
      width: 300px;
      height: 60px;
      .text {
        height: 111px;
        line-height: 111px;
        font-size: 35px;
        font-weight: 400;
        position: relative;
        text-indent: 80px;
        &:before {
          position: absolute;
          top: 50%;
          left: 20px;
          transform: translate(0, -50%);
          display: block;
          content: "";
          width: 41px;
          height: 47px;
          background: url("../../../assets/home/local.png") no-repeat;
          background-size: 100% 100%;
        }
      }
    }
  }
  .weatherInfo {
    margin-left: 16px;
    width: 797px;
    height: 130px;
    background: url("../../../assets/home/kuang.png") no-repeat;
    background-size: 100% 100%;
    //border-radius: 10px;
    //box-shadow: #225B8F 0px 0px 80px inset;
    font-size: 32px;
    font-weight: 400;
    .weatherInfo-left,
    .weatherInfo-content,
    .weatherInfo-right {
      display: inline-block;
      vertical-align: top;
      width: 33.33333%;
      text-align: center;
      .title {
        height: 80px;
        line-height: 75px;
      }
      .text {
        height: 60px;
      }
    }
    .weatherInfo-left,
    .weatherInfo-content {
      position: relative;
      &:after {
        display: block;
        position: absolute;
        right: 0;
        top: 47%;
        transform: translate(0, -50%);
        content: "";
        width: 1px;
        height: 110px;
        background: #3784b0;
      }
    }
  }
}
</style>
