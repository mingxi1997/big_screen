<template>
  <div>
    <el-dialog v-model="dialogVisible" title="陆生脊椎动物" :show-close="false" width="45%">
      <div class="btn_exit">
        <img
          src="../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="width: 0.13rem; float: right; margin-top: -0.23rem; cursor:pointer;"
        />
      </div>
      <div>
        <img
          src="../../../common/picture/qingwa.jpg"
          alt=""
          style="width: 4.4rem; margin-top: 0"
        />
      </div>
      <div style="margin-top: 0.03rem; margin-left: 0.6rem; text-align: center">
        <span id="Terrsest_name" style="font-fanily: 'FZMWFont'">两栖动物</span>
        <div style="float: right; margin-right: 0.2rem">
          种类：<span id="Terrsest_number">20</span>种
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer"> </span>
      </template>
    </el-dialog>
  </div>
  <div id="terrsest" style="width: 100%; height: 0.9rem" v-if="isShowEcharts"></div>
</template>

<script>
import * as echarts from "echarts";
import { ref, onUnmounted } from "vue";

export default {
  name: "Terrestrial",
  setup(){
    let isShowEcharts = ref(true);

    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    return{
      isShowEcharts,
    };
  },
  data() {
    const dialogVisible = ref(false);
    return { dialogVisible };
  },
  mounted() {
    var myChart = echarts.init(document.getElementById("terrsest"));
    var option = {
      title: {
        subtext: "单位：种",
        subtextStyle: {
          color: "#DDDDDD",
          fontSize: "0.07rem",
          align: "right",
          fontWeight: 400,
        },
        right: "5%",
        // textAlign: 'right'
      },
      backgroundColor: "transparent",
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow",
        },
      },
      grid: {
        left: "3%",
        right: "5%",
        bottom: "-10%",
        top: "13%",
        containLabel: true,
      },
      xAxis: [
        {
          type: "value",
          show: false,
        },
      ],
      yAxis: {
        type: "category",
        data: ["鸟类", "哺乳动物", "爬行动物", "两栖动物"],
        axisLine: {
          show: false,
        },
        axisTick: {
          show: false,
        },
        axisLabel: {
          fontSize: "0.07rem",
          fontFamily: "Microsoft YaHei",
          color: "#fff",
        },
      },
      color: {
        type: "linear",
        x: 0,
        y: 0,
        x2: 1,
        y2: 0,
        colorStops: [
          {
            offset: 0,
            color: "rgb(4, 56, 218)", // 0% 处的颜色
          },
          {
            offset: 1,
            color: "rgb(26, 178, 255)", // 100% 处的颜色
          },
        ],
        global: false, // 缺省为 false
      },
      series: [
        {
          name: "2011",
          type: "bar",
          label: {
            show: true,
            fontSize: "0.08rem",
            fontWeight: 600,
            position: "right",
            color: "rgb(26, 178, 255)",
          },
          data: [373, 92, 36, 20],
        },
      ],
    };
    myChart.setOption(option);
    window.addEventListener("resize", function () {
      // 自适应大小
      myChart.resize();
    });
    // myChart.on("click", function (params) {
    //   // 在用户点击后控制台打印数据的名称
    //   console.log(params);
    // });
    myChart.on("click", this.nav_open);
    myChart.on("click", function (param) {
      // console.log(param.name);
      const terrsestName = param.name;
      const terrsestNumber = param.value;
      // console.log(BirdName);
      document.getElementById("Terrsest_name").innerHTML = terrsestName;
      document.getElementById("Terrsest_number").innerHTML = terrsestNumber;
    });
  },
  methods: {
    nav_open() {
      this.dialogVisible = true;
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.085rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 3rem;
}
/deep/ .el-dialog__footer {
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
</style>
