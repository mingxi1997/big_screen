<template>
  <div class="habitatBox">
    <div class="habitat-left">
      <div class="svg">
        <div class="svgTitle">
          <div>总面积</div>
          <div>102,444.7</div>
        </div>
        <img class="img1" src="../../../assets/home/1.png" alt="" />
        <img class="img2" src="../../../assets/home/2.png" alt="" />
      </div>
    </div>
    <div class="habitat-right">
      <div class="title">生态系统分布总面积</div>
      <div class="text">102,444.7 <span>（单位：公顷）</span></div>
      <div style="float: left">
        <div class="item item1">耕地 55,583.8</div>
        <div class="item item2">林地 5,475.4</div>
        <div class="item item3">草地 797.4</div>
      </div>
      <div style="float: left;margin-left: 10px">
        <div class="item item4">水域 17,318.6</div>
        <div class="item item5">建设用地 23,187.7</div>
        <div class="item item6">未利用土地 81.8</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Habitat",
  components: {},
};
</script>

<style lang="less" scoped>
.habitatBox {
  width: 100%;
  height: 494px;
  .habitat-left {
    position: relative;
    height: 100%;
    width: 190px;
    display: inline-block;
    vertical-align: top;
    .svg {
      position: relative;
      width: 295px;
      height: 295px;
      top: 25%;
      left: 90%;
      transform: translateY(-50%);
      .svgTitle {
        position: absolute;
        top: 55%;
        left: 20%;
        transform: translate(0, -50%);
        font-size: 33px;
        font-family: Microsoft YaHei;
        font-weight: 400;
        z-index: 3;
      }
      img {
        display: block;
        position: absolute;
        top: 55%;
        left: 20%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 100%;
      }
      .img1 {
        animation: ant 5s;
        animation-iteration-count: infinite;
      }
      .img2 {
        animation: tna 5s;
        animation-iteration-count: infinite;
      }
      @keyframes ant {
        0% {
          transform: translate(-50%, -50%) rotate(0deg);
        }
        50% {
          transform: translate(-50%, -50%) rotate(0deg);
        }
        100% {
          transform: translate(-50%, -50%) rotate(360deg);
        }
      }
      @keyframes tna {
        0% {
          transform: translate(-50%, -50%) rotate(0deg);
        }
        50% {
          transform: translate(-50%, -50%) rotate(0deg);
        }
        100% {
          transform: translate(-50%, -50%) rotate(-360deg);
        }
      }
    }
  }
  .habitat-right {
    height: 70%;
    display: inline-block;
    vertical-align: top;
    width: 760px;
    padding-top: 2%;
    padding-left: 22%;
    box-sizing: border-box;
    .title {
      font-size: 22px;
      font-weight: 400;
      margin-bottom: 13px;
    }
    .text {
      font-size: 33px;
      font-weight: bold;
      margin-bottom: 38px;
      span {
        font-size: 18px;
      }
    }
    .item {
      height: 50px;
      line-height: 50px;
      font-size: 22px;
      font-weight: 400;
      text-indent: 2em;
      position: relative;
      &:before {
        position: absolute;
        top: 50%;
        left: 0;
        transform: translate(40%, -55%);
        display: block;
        width: 15px;
        height: 15px;
        content: "";
        border-radius: 50%;
      }
    }
    .item1:before {
      background: #2b23d4;
    }
    .item2:before {
      background: #23d472;
    }
    .item3:before {
      background: #d47623;
    }
    .item4:before {
      background: #5e1de3;
    }
    .item5:before {
      background: #5b83cd;
    }
    .item6:before {
      background: #8c8c8f;
    }
  }
}
</style>
