<template>
  <div class="home">
    <div class="head">
      <div class="left">
        <Weather />
      </div>
      <div class="right">
        <div class="infosBox">
          <div class="infos-left">
            <BlockInfo />
          </div>
          <div class="infos-right">
            <Habitat />
          </div>
        </div>
      </div>
    </div>
    <div class="body">
      <Homebody></Homebody>
    </div>
  </div>
</template>

<script>
import Weather from "./components/Weather";
import Habitat from "./components/Habitat";
import BlockInfo from "./components/BlockInfo";
import Homebody from "./body/Homebody";
import { computed } from "vue";

export default {
  name: "Home",
  components: {
    Homebody,
    BlockInfo,
    Habitat,
    Weather,
  },
  props: [],
  emits: [],
  setup(props, context) {
    return {};
  },
};
</script>

<style lang="less" scoped>
.home {
  margin: 0 40px;
  background: transparent;
  padding-top: 14px;
  font-size: 0.4vw;
  font-family: "Microsoft YaHei";
  .head {
    height: 270px;
    .left {
      width: 900px;
      display: inline-block;
      vertical-align: top;
    }
    .right {
      width: 2860px;
      display: inline-block;
      vertical-align: top;
      .infosBox {
        padding-left: 0px;
        padding-right: 0px;

        .infos-left,
        .infos-right {
          display: inline-block;
          vertical-align: top;
        }
        .infos-left {
        }
        .infos-right {
        }
      }
    }
  }
  .router-link-active {
    text-decoration: none;
  }
  .body {
    width: 100%;
    height: 100%;
    // background: yellow;
  }
  a {
    text-decoraction: none;
  }
}
</style>
