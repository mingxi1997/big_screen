<template>
  <div class="home_sta">
    <span
      style="
        position: absolute;
        font-size: 0.09rem;
        margin-top: 0.07rem;
        margin-left: 0.3rem;
      "
      >AI监测站</span
    >
    <img
      src="../../../../assets/back_home0.png"
      alt=""
      @click="doHome"
      style="
        width: 0.4rem;
        position: absolute;
        right: 27.5%;
        margin-top: 0.18rem;
        cursor: pointer;
        z-index: 9;
      "
    />
    <div class="map_sta" id="ai"></div>
    <div class="menu_sta">
      <router-view :key="$route.fullPath"></router-view>
    </div>
  </div>
</template>

<script>
import * as echarts from "echarts";
import { useRouter } from "vue-router";
import URL from '@/api/baseUrl'
import JIANGSU from "../../../../../public/jiangsu.json";
import MenuAi from "../menu/MenuAi.vue";

export default {
  components: {
    MenuAi,
  },
  setup () {
    const router = useRouter();
    const doHome = () => {
      // console.log('doHome');
      router.push("/");
    };
    window.doPart = (params) => {
      // console.log(params);
      router.push({
        name: "aipart",
        // path: '/aipart/:id',
        params: {
          name: params.name,
          num:  params.data.num,
        }
      });
    };
    return {
      doHome,
      doPart,
    };
  },
  data() {
    const point = [];
    return {
      point,
    };
  },
  created() {
    this.query_data();
  },
  // mounted() {
    // this.createMap();
  // },

  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/equip/name`).then((res) => {
        var a = JSON.stringify(res.data.equipPoint.aiPoint);
        this.point = JSON.parse(a);
        this.createMap();
      });
    },
    createMap() {
      var myChart = echarts.init(document.getElementById("ai")); // 拿到一个实例
      echarts.registerMap("江苏省", JIANGSU, {}); //引入地图文件
      // console.log(JSON);
      var option = {
        geo: {
          show: false,
          map: "江苏省",
          label: {
            show: false,
          },
          roam: true,
          itemStyle: {
            normal: {
              borderWidth: 3, //设置外层边框
              borderColor: "#1A9BEF",
              shadowColor: "rgba(26, 155, 239, 0.7)",
              shadowBlur: 12,
            },
            emphasis: {
              show: false,
              // areaColor: '#01215c'
            },
          },
        },
        series: [
          {
            type: "map",
            mapType: "江苏省", //地图名称
            color: "blue",
            roam: true,
            // center: [119.46,32.02],
            // zoom: 5,
            label: {
              show: true,
              color: "white",
              fontSize: "0.08rem",
              position: "inside",
              textShadowColor: "white",
              textShadowBlur: 6,
            },
            itemStyle: {
              // color: '#FF1E1E',
              areaColor: "rgb(0, 8, 45)",
              borderColor: "#1A9BEF",
              borderWidth: 1,
              shadowColor: "rgba(26, 155, 239, 0.5)",
              shadowBlur: 6,
            },
            emphasis: {
              label: {
                show: true,
                position: "inside",
                color: "white",
                fontSize: "0.08rem",
                textShadowColor: "white",
                textShadowBlur: 6,
              },
              itemStyle: {
                areaColor: "rgb(0, 79, 131)",
              },
            },
            select: {
              disabled: true,
              label: {
                show: true,
                position: "inside",
                color: "white",
                fontSize: "0.08rem",
                textShadowColor: "white",
                textShadowBlur: 6,
              },
              itemStyle: {
                areaColor: "#145E8E",
              },
            },
            markPoint: {
              // symbol: "pin",
              symbol:
                "image://" +
                require("../../../../assets/mapdatav/yuan 已建成.png"),
              symbolSize: 20,
              label: {
                show: true,
                color: "white",
              },
              symbolStyle: {
                color: "yellow",
              },
              emphasis: {
                label: {
                  show: true,
                },
              },
              data: this.point,
            },
          },
        ],
      };
      myChart.setOption(option);
      document.getElementById('ai').setAttribute('_echarts_instance_','');
      myChart.on("click", function (params) {
        if (params.componentType == "markPoint") {
          doPart(params);
        }
      });
      window.addEventListener("resize", function () {
        // 自适应大小
        myChart.resize();
      });
    },
  },
};
</script>

<style>
.router-link-active {
  text-decoration: none;
}
.home_sta {
  margin-top: 1%;
  height: 100%;
  width: 100%;
}
.map_sta {
  float: left;
  margin-right: 2%;
  height: 1500px;
  width: 1900px;
  background: url("../../../../assets/hdbj.png") no-repeat;
  background-size: 100% 100%;
}
.menu_sta {
  float: left;
  width: 30%;
  height: 1500px;
  background: url("../../../../assets/hdbjr.png") no-repeat;
  background-size: 100% 100%;
}
</style>
