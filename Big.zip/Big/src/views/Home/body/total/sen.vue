<template>
  <div class="home_sta">
    <span
      style="
        position: absolute;
        font-size: 0.09rem;
        margin-top: 0.07rem;
        margin-left: 0.3rem;
      "
      >首页</span
    >
    <div class="map_sta" id="sen"></div>
    <div class="menu_sta">
      <div class="protectBox">
        <div
          class="item"
          @click="onChoose(index)"
          @mouseover="onSelect(index)"
          :class="{ action: index === action }"
          v-for="(item, index) in list"
          :key="index"
        >
          <div>{{ item }}</div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import * as echarts from "echarts";
import { useRouter } from "vue-router";
import { ref, onUnmounted } from "vue";
import JIANGSU from "../../../../../public/jiangsu.json";

export default {
  components: {
  },
  setup() {
    let isShowEcharts = ref(true);

    onUnmounted(() => {
      isShowEcharts.value = false;
    });

    const router = useRouter();
    window.doUrl = () => {
      router.push("/substation");
    };

    const action = ref(0);
    const list = ref([
      "南京沿江湿地综合观测站",
      "镇江长江豚类保护湿地观测样区",
      "扬州三江营湿地观测样区",
      "泰州沿江重要湿地观测样区",
      "南通长江口北支湿地观测样区",
      "太湖湖泊湿地综合观测站",
      "泗洪洪泽湖湿地综合观测站",
      "苏州西山岛观测样区",
      "泰州兴化里下河湿地观测样区",
      "宿迁骆马湖湿地观测样区",
      "盐城滨海湿地综合观测站",
      "大丰麋鹿保护湿地观测样区",
      "盐城条子泥湿地观测样区",
      "连云港临洪河口湿地观测样区",
      "宜兴龙池山森林综合观测站",
      "常州天目山森林观测样区",
      "南京老山森林观测样区",
      "盱眙铁山寺森林观测样区",
      "徐州大洞山森林观测样区",
      "连云港云台山森林观测样区",
    ]);
    return {
      isShowEcharts,
      list,
      action,
    };
  },
  data() {
    const point = [
      {
        name: "南京沿江湿地生物多样性综合观测站",
        coord: [118.78, 32.04],
        value: 0,
        class: "沿江热点区域",
        symbol:
          "image://" + require("../../../../assets/mapdatav/huanbaoting.png"),
        symbolSize: 20,
      },
      {
        name: "宜兴龙池山森林生物多样性综合观测站",
        coord: [119.698156, 31.212468],
        value: 14,
        class: "低山丘陵热点区域",
      },
      {
        name: "常州天目山森林生物多样性观测样区",
        coord: [119.420751, 31.276457],
        value: 15,
        class: "低山丘陵热点区域",
      },
      {
        name: "南京老山森林生物多样性观测样区",
        coord: [118.577206, 32.095588],
        value: 16,
        class: "低山丘陵热点区域",
      },
      {
        name: "盱眙铁山寺森林生物多样性观测样区",
        coord: [118.480278, 32.737134],
        value: 17,
        class: "低山丘陵热点区域",
      },
      {
        name: "徐州大洞山森林生物多样性观测样区",
        coord: [117.503855, 34.403794],
        value: 18,
        class: "低山丘陵热点区域",
      },
      {
        name: "连云港云台山森林生物多样性观测样区",
        coord: [119.435042, 34.717504],
        value: 19,
        class: "低山丘陵热点区域",
      },
    ];
    return {
      point,
    };
  },
  mounted() {
    this.createMap();
  },
  methods: {
    onChoose(index) {
      this.action = index;
      doUrl();
    },
    onSelect(index) {
      // console.log(index);
      this.action = index;
    },
    createMap() {
      var myChart = echarts.init(document.getElementById("sen")); // 拿到一个实例
      echarts.registerMap("江苏省", JIANGSU, {}); //引入地图文件
      // console.log(JSON);
      var option = {
        geo: {
          show: true,
          map: "江苏省",
          label: {
            show: false,
          },
          roam: false,
          itemStyle: {
            normal: {
              borderWidth: 3, //设置外层边框
              borderColor: "#1A9BEF",
              shadowColor: "rgba(26, 155, 239, 0.7)",
              shadowBlur: 12,
            },
            emphasis: {
              show: false,
              // areaColor: '#01215c'
            },
          },
        },
        series: [
          {
            type: "map",
            mapType: "江苏省", //地图名称
            color: "blue",
            roam: false,
            // center: [118.46,32.02],
            // zoom: 1,
            label: {
              show: true,
              color: "white",
              fontSize: "0.08rem",
              position: "inside",
              textShadowColor: "white",
              textShadowBlur: 6,
            },
            itemStyle: {
              // color: '#FF1E1E',
              areaColor: "rgb(0, 8, 45)",
              borderColor: "#1A9BEF",
              borderWidth: 1,
              shadowColor: "rgba(26, 155, 239, 0.5)",
              shadowBlur: 6,
            },
            emphasis: {
              label: {
                show: true,
                position: "inside",
                color: "white",
                fontSize: "0.08rem",
                textShadowColor: "white",
                textShadowBlur: 6,
              },
              itemStyle: {
                areaColor: "rgb(0, 79, 131)",
              },
            },
            select: {
              label: {
                show: true,
                position: "inside",
                color: "white",
                fontSize: "0.08rem",
                textShadowColor: "white",
                textShadowBlur: 6,
              },
              itemStyle: {
                areaColor: "#145E8E",
              },
            },
            markPoint: {
              // symbol: "pin",
              symbol: "circle",
              symbolSize: 25,
              itemStyle: {
                color: {
                  type: "radial",
                  x: 0.5,
                  y: 0.5,
                  r: 0.5,
                  colorStops: [
                    {
                      offset: 0.3,
                      color: "lightgreen", // 0% 处的颜色
                    },
                    {
                      offset: 1,
                      color: "transparent", // 100% 处的颜色
                    },
                  ],
                  global: false, // 缺省为 false
                },
              },
              label: {
                show: false,
                color: "white",
              },
              symbolStyle: {
                color: "yellow",
              },
              emphasis: {
                label: {
                  show: true,
                  position: "top",
                  color: "white",
                  formatter: "{b}",
                  width: 152,
                  fontSize: 15,
                  lineHeight: 22,
                  borderWidth: 2,
                  borderRadius: 4,
                  borderColor: "#F7B108",
                  backgroundColor: "rgba(100, 100, 100, 0.6 )",
                  shadowColor: "#F7B108",
                  shadowBlur: 8,
                  overflow: 'break'
                },
                itemStyle: {
                  symbolSize: 35,
                  borderWidth: 15,
                  borderColor: {
                    type: "radial",
                    x: 0.5,
                    y: 0.5,
                    r: 0.5,
                    colorStops: [
                      {
                        offset: 0,
                        color: "rgba(255, 255, 255, 0.4)", // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: "transparent", // 100% 处的颜色
                      },
                    ],
                    global: false, // 缺省为 false
                  },
                },
              },
              data: this.point,
            },
          },
        ],
      };
      myChart.setOption(option);
      document.getElementById('sen').setAttribute('_echarts_instance_','');
      myChart.on("mouseover", (params) => {
        if (params.componentType == "markPoint") {
          // console.log(params.value);
          this.onSelect(params.value);
        }
      });
      myChart.on("click", function (params) {
        // var pixelPoint = [params.offsetX, params.offsetY];
        // var dataPoint = myChart.convertFromPixel({ geoIndex: 0 }, pixelPoint);
        // console.log(dataPoint);
        // console.log(params);
        if (params.componentType == "markPoint") {
          // console.log(13);
          doUrl();
        }
      });
      window.addEventListener("resize", function () {
        // 自适应大小
        myChart.resize();
      });
    },
    mouseclick() {
      doUrl();
    },
  },
};
</script>

<style lang="less" scoped>
.router-link-active {
  text-decoration: none;
}
.home_sta {
  margin-top: 1%;
  height: 100%;
  width: 100%;
}
.map_sta {
  float: left;
  margin-right: 2%;
  height: 1500px;
  width: 1900px;
  background: url("../../../../assets/hdbj.png") no-repeat;
  background-size: 100% 100%;
}
.menu_sta {
  float: left;
  width: 30%;
  height: 1500px;
  background: url("../../../../assets/hdbjr.png") no-repeat;
  background-size: 100% 100%;
}

.protectBox {
  width: 100%;
  height: 536px;
  padding-top: 80px;
  box-sizing: border-box;
  font-weight: 200;
  color: rgba(255, 255, 255, 0.9);
  .item {
    width: 250px;
    height: 120px;
    margin-left: 8%;
    margin-bottom: 20px;
    padding-left: 0.1rem;
    padding-right: 0.1rem;
    font-size: 0.075rem;
    letter-spacing: 0.005rem;
    line-height: 0.11rem;
    background: url("../../../../assets/home/btnbg.png") no-repeat;
    background-size: 100% 100%;
    display: inline-block;
    vertical-align: top;
    cursor: pointer;
    div {
      width: 100%;
      height: 100%;
      padding: 10px;
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      text-align: center;
    }
  }
  .action {
    background-image: url("../../../../assets/home/btnbg-a.png") !important;
  }
}
</style>
