<template>
  <div class="aimain">
    <div class="title">
      <span>AI监测站：</span>
    </div>

    <div class="text">
      <p>设备总数：{{ total }}</p>
      <p>运行正常：{{ normal }}</p>
      <p>运行异常：{{ wrong }}</p>
      <br />
      <div class="intro_img">
        <img src="@/assets/introduct/ai.jpg" alt="" style="width: 100%" />
      </div>
      <div class="intro_text">
        <p>
          {{ intro }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import URL from '@/api/baseUrl'

export default {
  components: {
  },
  setup() {
    return {
    };
  },
  data() {
    var total,normal,wrong,intro;
    return {
      total,
      normal,
      wrong,
      intro,
    };
  },
  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/equip/name`).then((res) => {
        // console.log(res.data);
        this.total = res.data.equip.ai.total;
        this.normal = res.data.equip.ai.normal;
        this.wrong = res.data.equip.ai.wrong;
        this.intro = res.data.equip.ai.intro;
      });
    },
  },
  created(name) {
    this.query_data(name);
  },
};
</script>

<style lang="less">
.aimain {
  width: 100%;
  height: 90%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 94%;
    padding: 2% 5% 5% 5%;
    margin-top: 10%;
    margin-left: 5%;
    margin-bottom: 3%;
    color: rgba(255, 255, 255, 0.9);
    font-family: "Microsoft YaHei";
    font-size: 36px;
    line-height: 52px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
  .intrp_img {
    width: 100%;
  }
  .intro_text {
    margin-top: 2%;
    text-indent: 10%;
  }
}
</style>
