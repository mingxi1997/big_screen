<template>
  <div class="quesmain">
    <div class="title">问题分布：</div>
    <div class="text">
      <p v-for="(item, index) in questreating" :key="index">{{ item.name.replace("生物多样性","") }}:    {{item.value}}个</p>
      <br />
    </div>
    <div class="title_down">历史数据：</div>
    <div class="history">
      <p v-for="(item, index) in quesuntreated" :key="index">{{ item.name.replace("生物多样性","") }}:    {{item.value}}个</p>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import URL from '@/api/baseUrl'

export default {
  components: {
  },
  setup() {
    return {
    };
  },
  data() {
    var quesnum;
    var questreating = [];
    var quesuntreated = [];
    return {
      quesnum,
      questreating,
      quesuntreated,
    };
  },
  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/ques/name`).then((res) => {
        // console.log(res.data.quesPoint);
        this.quesnum = res.data.quesPoint;
        for(var i=0;i<this.quesnum.length;i++){
          if(this.quesnum[i].state == 'treating'){
            this.questreating.push(this.quesnum[i])
          }
          else{
            this.quesuntreated.push(this.quesnum[i])
          }
        }
        // console.log(this.quesuntreated);
      });
    },
  },
  created(name) {
    this.query_data(name);
  },
};
</script>

<style lang="less">
.quesmain {
  width: 100%;
  height: 60%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 90%;
    padding: 5%;
    margin-left: 5%;
    margin-bottom: 3%;
    font-size: 36px;
    line-height: 50px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
  .video {
    margin-top: 2%;
    width: 100%;
    height: 56%;
    background: rgba(0, 0, 0, 0.5);
    .video_container {
      width: 90%;
      margin-left: 5%;
      padding-top: 2%;
    }
  }
  .history {
    width: 80%;
    height: 30%;
    padding: 5%;
    margin-top: 8%;
    margin-left: 5%;
    font-size: 36px;
    line-height: 50px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
}
</style>
