<template>
  <div class="eqi">
    <div class="title">江苏省各县、市、区生态质量指数初步测算及排名情况</div>
    <div class="text">
      <el-scrollbar height="100%">
        <ul
          v-for="(item, index) in ranking"
          :key="index"
          class="scrollbar-demo-item"
        >
          {{ index + 1 }}
          {{ item.name }}
          {{ item.number }}
          {{ item.form }}
        </ul>
      </el-scrollbar>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import VideoPlayer from "../VideoPlayer.vue";
import "video.js/dist/video-js.css";

export default {
  components: {
    VideoPlayer,
  },
  setup() {
    const videoRef = ref(null);
    return {
      videoRef,
    };
  },
  data() {
    const ranking = [
      {
        name: "盱眙县",
        number: 65.6,
        coord: [118.05, 33],
        form: "二类",
      },
      {
        name: "金湖县",
        number: 65.3,
        coord: [119.02, 33.02],
        form: "二类",
      },
      {
        name: "溧阳市",
        number: 64.0,
        coord: [119.48, 31.42],
        form: "二类",
      },
      {
        name: "泗洪县",
        number: 63.3,
        coord: [118.22, 33.47],
        form: "二类",
      },
      {
        name: "宜兴市",
        number: 63.2,
        coord: [119.82, 31.35],
        form: "二类",
      },
      {
        name: "洪泽区",
        number: 62.0,
        coord: [118.83, 33.3],
        form: "二类",
      },
      {
        name: "高邮市",
        number: 61.1,
        coord: [119.43, 32.78],
        form: "二类",
      },
      {
        name: "射阳县",
        number: 60.7,
        coord: [120.25, 33.78],
        form: "二类",
      },
      {
        name: "高淳区",
        number: 60.2,
        coord: [118.88, 31.33],
        form: "二类",
      },
      {
        name: "宝应县",
        number: 59.6,
        coord: [119.3, 33.23],
        form: "二类",
      },
      {
        name: "金坛区",
        number: 58.9,
        coord: [119.57, 31.75],
        form: "二类",
      },
      {
        name: "泗阳县",
        number: 58.0,
        coord: [118.68, 33.72],
        form: "二类",
      },
      {
        name: "如东县",
        number: 57.9,
        coord: [121.18, 32.32],
        form: "二类",
      },
      {
        name: "响水县",
        number: 57.5,
        coord: [119.57, 34.2],
        form: "二类",
      },
      {
        name: "滨海县",
        number: 57.1,
        coord: [119.83, 33.98],
        form: "二类",
      },
      {
        name: "阜宁县",
        number: 56.2,
        coord: [119.8, 33.78],
        form: "二类",
      },
      {
        name: "句容市",
        number: 56.1,
        coord: [119.17, 31.95],
        form: "二类",
      },
      {
        name: "东台市",
        number: 54.9,
        coord: [120.3, 32.85],
        form: "三类",
      },
      {
        name: "建湖县",
        number: 54.0,
        coord: [119.8, 33.47],
        form: "三类",
      },
      {
        name: "灌云县",
        number: 53.4,
        coord: [119.25, 34.3],
        form: "三类",
      },
      {
        name: "新沂市",
        number: 53.4,
        coord: [118.35, 34.38],
        form: "三类",
      },
      {
        name: "盐都区",
        number: 52.6,
        coord: [120.15, 33.33],
        form: "三类",
      },
      {
        name: "苏州市区",
        number: 52.5,
        coord: [120.58, 31.3],
        form: "三类",
      },
      {
        name: "宿豫区",
        number: 52.3,
        coord: [118.32, 33.95],
        form: "三类",
      },
      {
        name: "启东市",
        number: 51.9,
        coord: [121.65, 31.82],
        form: "三类",
      },
      {
        name: "东海县",
        number: 51.3,
        coord: [118.77, 34.53],
        form: "三类",
      },
      {
        name: "江宁区",
        number: 50.2,
        coord: [118.85, 31.95],
        form: "三类",
      },
      {
        name: "仪征市",
        number: 50.1,
        coord: [119.18, 32.27],
        form: "三类",
      },
      {
        name: "涟水县",
        number: 49.9,
        coord: [119.27, 33.78],
        form: "三类",
      },
      {
        name: "昆山市",
        number: 49.8,
        coord: [120.98, 31.38],
        form: "三类",
      },
      {
        name: "大丰区",
        number: 49.3,
        coord: [120.47, 33.2],
        form: "三类",
      },
      {
        name: "兴化市",
        number: 49.1,
        coord: [119.85, 32.92],
        form: "三类",
      },
      {
        name: "南京市区",
        number: 48.8,
        coord: [118.78, 32.07],
        form: "三类",
      },
      {
        name: "海安县",
        number: 48.7,
        coord: [120.45, 32.55],
        form: "三类",
      },
      {
        name: "宿迁市区",
        number: 48.5,
        coord: [118.28, 33.97],
        form: "三类",
      },
      {
        name: "六合区",
        number: 48.2,
        coord: [118.83, 32.35],
        form: "三类",
      },
      {
        name: "铜山区",
        number: 47.9,
        coord: [117.17, 34.18],
        form: "三类",
      },
      {
        name: "丹阳市",
        number: 47.9,
        coord: [119.57, 32.0],
        form: "三类",
      },
      {
        name: "浦口区",
        number: 47.8,
        coord: [118.62, 32.05],
        form: "三类",
      },
      {
        name: "睢宁县",
        number: 47.7,
        coord: [117.95, 33.9],
        form: "三类",
      },
      {
        name: "灌南县",
        number: 47.7,
        coord: [119.35, 34.08],
        form: "三类",
      },
      {
        name: "常熟市",
        number: 46.8,
        coord: [120.74, 31.64],
        form: "三类",
      },
      {
        name: "邳州市",
        number: 46.7,
        coord: [117.95, 34.32],
        form: "三类",
      },
      {
        name: "淮阴区",
        number: 46.4,
        coord: [119.03, 33.63],
        form: "三类",
      },
      {
        name: "沭阳县",
        number: 46.4,
        coord: [118.77, 34.13],
        form: "三类",
      },
      {
        name: "溧水区",
        number: 46.2,
        coord: [119.02, 31.65],
        form: "三类",
      },
      {
        name: "盐城市区",
        number: 46.1,
        coord: [120.15, 33.35],
        form: "三类",
      },
      {
        name: "沛县",
        number: 45.3,
        coord: [116.93, 34.73],
        form: "三类",
      },
      {
        name: "扬州市区",
        number: 45.2,
        coord: [119.4, 32.4],
        form: "三类",
      },
      {
        name: "连云港市区",
        number: 45.0,
        coord: [119.22, 34.6],
        form: "三类",
      },
      {
        name: "新北区",
        number: 44.9,
        coord: [119.97, 31.83],
        form: "三类",
      },
      {
        name: "贾汪区",
        number: 44.9,
        coord: [117.45, 34.45],
        form: "三类",
      },
      {
        name: "淮安区",
        number: 44.7,
        coord: [119.02, 33.62],
        form: "三类",
      },
      {
        name: "无锡市区",
        number: 44.3,
        coord: [120.3, 31.57],
        form: "三类",
      },
      {
        name: "徐州市区",
        number: 44.1,
        coord: [117.18, 34.27],
        form: "三类",
      },
      {
        name: "南通市区",
        number: 44.0,
        coord: [120.88, 31.98],
        form: "三类",
      },
      {
        name: "丰县",
        number: 43.7,
        coord: [116.6, 34.7],
        form: "三类",
      },
      {
        name: "姜堰区",
        number: 43.5,
        coord: [120.15, 32.52],
        form: "三类",
      },
      {
        name: "镇江市区",
        number: 43.3,
        coord: [119.45, 32.2],
        form: "三类",
      },
      {
        name: "淮安市区",
        number: 42.6,
        coord: [119.02, 33.62],
        form: "三类",
      },
      {
        name: "如皋市",
        number: 42.6,
        coord: [120.57, 32.4],
        form: "三类",
      },
      {
        name: "武进区",
        number: 42.4,
        coord: [119.93, 31.72],
        form: "三类",
      },
      {
        name: "江都区",
        number: 42.4,
        coord: [119.55, 32.43],
        form: "三类",
      },
      {
        name: "泰兴市",
        number: 42.4,
        coord: [120.02, 32.17],
        form: "三类",
      },
      {
        name: "太仓市",
        number: 41.1,
        coord: [121.1, 31.45],
        form: "三类",
      },
      {
        name: "通州区",
        number: 40.7,
        coord: [121.07, 32.08],
        form: "三类",
      },
      {
        name: "丹徒区",
        number: 40.6,
        coord: [119.45, 32.13],
        form: "三类",
      },
      {
        name: "靖江市",
        number: 40.6,
        coord: [120.27, 32.02],
        form: "三类",
      },
      {
        name: "海门市",
        number: 40.6,
        coord: [121.17, 31.9],
        form: "三类",
      },
      {
        name: "扬中市",
        number: 40.1,
        coord: [119.82, 32.23],
        form: "三类",
      },
      {
        name: "江阴市",
        number: 39.9,
        coord: [120.27, 31.9],
        form: "四类",
      },
      {
        name: "吴江区",
        number: 38.6,
        coord: [120.63, 31.17],
        form: "四类",
      },
      {
        name: "泰州市区",
        number: 38.3,
        coord: [119.92, 32.45],
        form: "四类",
      },
      {
        name: "高港区",
        number: 38.1,
        coord: [119.84, 32.33],
        form: "四类",
      },
      {
        name: "常州市区",
        number: 38.0,
        coord: [119.95, 31.78],
        form: "四类",
      },
      {
        name: "张家港市",
        number: 37.4,
        coord: [120.55, 31.87],
        form: "四类",
      },
    ];
    return {
      ranking,
    };
  },
};
</script>

<style lang="less">
.eqi {
  width: 100%;
  height: 100%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 31px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 88%;
    padding: 2% 5% 5% 5%;
    // padding-left: 5%;
    // padding-right: 5%;
    margin-left: 5%;
    margin-bottom: 3%;
    font-size: 34px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
  .scrollbar-demo-item {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 60px;
    margin-bottom: 15px;
    margin-left: 5px;
    margin-right: 10px;
    text-align: center;
    border-bottom: 4px solid rgba(220, 220, 180, 0.7);
    border-left: 2px solid rgba(200, 200, 160, 0.5);
    border-radius: 4px;
    background: rgba(150, 150, 150, 0.5);
    color: white;
  }
.el-scrollbar__bar{
  width: 30px!important;
}
.el-scrollbar__wrap{
  width: 95%;
  overflow-y: auto;
  overflow-x:hidden;
}
.el-scrollbar__thumb {
  ////可设置滚动条颜色
  background: white;
}
}
</style>
