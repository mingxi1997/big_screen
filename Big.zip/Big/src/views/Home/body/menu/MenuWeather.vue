<template>
  <div class="tower">
    <div class="title">
      <span>设备状态：</span>
      <img
        src="../../../../assets/back_home1.png"
        alt=""
        @click="doHome"
        style="
          width: 0.13rem;
          float: right;
          margin-top: 0.01rem;
          margin-right: 0.08rem;
          cursor: pointer;
        "
      />
    </div>
    <div class="text">
      <p>站点名：{{ name }}</p>
      <br />
      <p>编号：{{ num }}</p>
      <br />
      <p>状态：{{ sta }}</p>
    </div>
    <div class="title_down">历史数据：</div>
    <div class="history">
      <p>{{ his }}</p>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import { useRouter } from "vue-router";

export default {
  props:['name'],
  components: {
  },
  setup() {
    const router = useRouter();
    const doHome = () => {
      router.push("/weathermain");
    };
    return {
      doHome,
    };
  },
  data() {
    var name = this.$route.params.name; 
    var num = this.$route.params.num; 
    const sta = "工作中";
    const his = "2022-04-10";
    return {
      name,
      num,
      sta,
      his,
    };
  },
};
</script>

<style lang="less">
.tower {
  width: 100%;
  height: 60%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 40%;
    padding: 5%;
    margin-left: 5%;
    margin-bottom: 3%;
    font-size: 34px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
  .video {
    margin-top: 2%;
    width: 100%;
    height: 56%;
    background: rgba(0, 0, 0, 0.5);
    .video_container {
      width: 90%;
      margin-left: 5%;
      padding-top: 2%;
    }
  }
  .history {
    width: 80%;
    height: 30%;
    padding: 5%;
    margin-top: 8%;
    margin-left: 5%;
    font-size: 30px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
}
</style>
