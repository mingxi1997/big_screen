<template>
  <div class="question">
    <div class="title_ques">
      <span>问题列表：</span>
      <img
        src="../../../../assets/back_home1.png"
        alt=""
        @click="doHome"
        style="
          width: 0.13rem;
          float: right;
          margin-top: 0.01rem;
          margin-right: 0.08rem;
          cursor: pointer;
        "
      />
    </div>
    <div class="text">
      <p>{{ name }}</p>
      <br>
      <div
        v-for="(item, index) in question"
        :key="index"
        class="ques_list"
        @click="nav_open(index)"
        style="cursor: pointer"
      >
        {{ index + 1 }} {{ item }}
      </div>
    </div>
  </div>
  <div>
    <el-dialog v-model="dialogVisible" title="问题详情" :show-close="false">
      <div class="btn_exit">
        <img
          src="../../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="
            width: 0.13rem;
            float: right;
            margin-top: -0.23rem;
            cursor: pointer;
          "
        />
      </div>
      <div>
        <div style="margin-top: 0.03rem; text-align: center">
          <p id="Group_name" style="font-fanily: 'FZMWFont'">
            {{ quesIntro }}
          </p>
        </div>
        <img
          :src= "geturl(img)"
          alt=""
          style="width: 4.9rem;height:2.75rem; margin-top: 0.05rem"
        />
      </div>
      <template #footer>
        <span class="dialog-footer">问题状态：{{ quesState }}</span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref } from "vue";
import URL from '@/api/baseUrl'
import { useRouter } from "vue-router";
export default {
  setup() {
    const router = useRouter();
    const doHome = () => {
      router.push("/quesmain");
    };
    return {
      doHome,
    };
  },
  data() {
    const dialogVisible = ref(false);
    var name = this.$route.params.name; 
    var question = this.$route.params.question; 
    var quesInfo,quesIntro,quesPicture,quesState;
    return {
      dialogVisible,
      name,
      question,
      quesInfo,
      quesIntro,
      quesPicture,
      quesState,
    };
  },
  created() {
    this.query_data();
  },
  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/ques/name`).then((res) => {
        var a = JSON.stringify(res.data.quesInfo);
        this.quesInfo = JSON.parse(a);
        // console.log(this.quesInfo);
      });
    },
    nav_open(index) {
      // console.log(index);
      this.dialogVisible = true;
      this.quesIntro = this.quesInfo[index].introduction;
      this.quesPicture = this.quesInfo[index].picname;
      this.quesState = this.quesInfo[index].state;
    },
    geturl(img){
      return require("@/common/picture/"+this.quesPicture+".jpg");
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.1rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.85rem;
}
/deep/ .el-dialog__footer {
  padding-top: 0.06rem;
  font-size: 0.1rem;
  font-weight: 600;
  line-height: 0.08rem;
  color: rgb(199, 22, 22);
  align-items: center;
  text-align: center;
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
.question {
  width: 100%;
  height: 70%;
  align-content: center;
  // background: yellow;
  .title_ques {
    padding-left: 6%;
    margin-bottom: 12%;
    height: 1px;
    line-height: 68px;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .text {
    width: 80%;
    height: 100%;
    padding: 5%;
    margin-left: 5%;
    font-size: 36px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
    .ques_list {
      line-height: 60px;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid rgba(255,255,255,0.8);
      border-radius: 10px;
      background: rgba(150, 150, 150, 0.5);
    }
    .ques_list:hover {
      background: rgba(253, 203, 37, 0.7);
    }
  }
}
.state {
  padding-top: 2%;
  padding-left: 10%;
  margin-bottom: 15%;
  height: 1px;
  line-height: 160px;
  position: relative;
  font-size: 49px;
  font-weight: bold;
  font-style: italic;
}
.state_now {
  margin-left: 25%;
  padding-top: 1.5%;
  padding-left: 10%;
  color: #ffb54c;
  font-weight: bold;
  position: relative;
  font-size: 80px;
  text-shadow: #ffb54c 0px 0px 30px;
  line-height: 160px;
}
</style>
