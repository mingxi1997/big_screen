<template>
  <div class="ai">
    <div class="title">
      <span>设备状态：</span>
      <img
        src="../../../../assets/back_home1.png"
        alt=""
        @click="doHome"
        style="
          width: 0.13rem;
          float: right;
          margin-top: 0.01rem;
          margin-right: 0.08rem;
          cursor: pointer;
        "
      />
    </div>
    <div class="text">
      <p>站点名：{{ name }}</p>
      <br />
      <p>编号：{{ num }}</p>
      <br />
      <p>状态：{{ sta }}</p>
    </div>
    <div class="title_down">实时监控：</div>
    <div class="video">
      <div class="video_container">
        <video-player ref="videoRef" class="video" :options="videoOptions" />
      </div>
    </div>
    <div class="title_down">历史数据：</div>
    <div class="history">{{ his }}</div>
  </div>
</template>

<script>
import { ref } from "vue";
import { useRouter } from "vue-router";
import VideoPlayer from "../VideoPlayer.vue";
import "video.js/dist/video-js.css";

export default {
  components: {
    VideoPlayer,
  },
  setup() {
    const router = useRouter();
    const videoRef = ref(null);
    const doHome = () => {
      router.push("/aimain");
    };
    return {
      videoRef,
      doHome,
    };
  },
  data() {
    var name = this.$route.params.name; 
    var num = this.$route.params.num; 
    const sta = "工作中";
    const his = "2022-02-21";
    const videoOptions = {
      autoplay: true,
      controls: true,
      loop: true, //视频一结束就重新开始
      aspectRatio: "16:9",
      fullscreen: {
        options: { navigationUI: "hide" },
      },
      sources: [
        {
          src: require("../../../../common/video/yan.7f04c582.mp4"),
          type: "video/mp4",
          // src: "http://36.152.9.59:39980/live/0/hls.m3u8?secret=1443ffb0-2f5b-4c85-ad33-55ccfe67c2f1",
          // type: "application/vnd.apple.mpegurl",
        },
      ],
    };
    return {
      name,
      num,
      sta,
      videoOptions,
      his,
    };
  },
};
</script>

<style lang="less">
.ai {
  width: 100%;
  height: 60%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 20%;
    padding: 5%;
    margin-left: 5%;
    margin-bottom: 3%;
    font-size: 34px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
  .video {
    margin-top: 8%;
    // padding-top: 5%;
    width: 100%;
    height: 63%;
    background: rgba(0, 0, 0, 0.5);
    .video_container {
      padding-top: 0.01%;
      position: initial;
      width: 90%;
      margin-left: 5%;
    }
  }
  .history {
    width: 80%;
    height: 30%;
    padding: 5%;
    margin-top: 8%;
    margin-left: 5%;
    font-size: 30px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
}
</style>
