<template>
  <div class="=home">
    <div class="left">
      <MyTitle>EQI指标</MyTitle>
      <router-link to="/eqi"> <Eqi /></router-link>
      <MyTitle>生物多样性</MyTitle>
      <Bio />
      <MyTitle>监管督办</MyTitle>
      <router-link to="/quesmain"> <Ques /></router-link>
      <MyTitle>设备管理</MyTitle>
      <Equipment />
      <MyTitle>预报预警弹窗</MyTitle>
      <RealTime />
    </div>
    <div class="right">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import MyTitle from "../components/MyTitle";
import Equipment from "../components/Equipment";
import Eqi from "../components/Eqi";
import Protect from "../components/Protect";
import RealTime from "../components/RealTime";
import Map from "../components/Map";
import Bio from "../components/Bio";
import Ques from "../components/Ques";
import { computed } from "vue";

export default {
  name: "Home",
  components: {
    Ques,
    Bio,
    Map,
    RealTime,
    Protect,
    Eqi,
    MyTitle,
    Equipment,
  },
  props: [],
  emits: [],
  setup(props, context) {
    return {};
  },
};
</script>

<style lang="less" scoped>
.router-link-active {
  text-decoration: none!important;
}
.home {
  width: 100%;
  height: 1560px;
  background: transparent;
  margin: 0 40px;
  padding-top: 14px;
  font-size: 0.4vw;
  font-family: "Microsoft YaHei";
  .left {
    width: 900px;
    display: inline-block;
    vertical-align: top;
  }
  .right {
    width: 2860px;
    height: 1575px;
    display: inline-block;
    vertical-align: top;
    background: transparent;
  }
  a {
    text-decoraction: none;
  }
}
</style>
