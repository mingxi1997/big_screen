<template>
  <div class="biomenu">
    <div class="title">物种分布：</div>
    <div class="text">
      <p>
        物种的分布是静态的又是动态的,
        是其生态位在历史过程中复杂表达的结果。在某一历史时期,
        同一物种的生态位在不同环境下的表达亦是不同的。在不同的环境尺度下,
        影响物种分布的各类因素的作用程度是不同的。Soberón和Peterson(2005)将影响物种分布的因素总结为以下4类:
      </p>
      <p>
        (1)非生物因素(abiotic or scenopoetic factor),
        包括气候、土壤条件等影响物种生理特性的各种因子;
      </p>
      <p>
        (2)物种间的相互作用(biotic or bionomic factor),
        可以是对物种有利的(如物种间的互利共生等),
        也可以是不利的(如竞争、取食等);
      </p>
      <p>
        (3)该地区位于物种的迁移能力范围之内,
        这取决于物种本身的迁移能力和地理区域的特性;
      </p>
      <p>
        (4)物种或种群对新环境的适应能力, 即在新的环境下,
        物种改变其生理特性以适应环境的能力。
      </p>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import VideoPlayer from "../VideoPlayer.vue";
import "video.js/dist/video-js.css";

export default {
  components: {
    VideoPlayer,
  },
  setup() {
    const videoRef = ref(null);
    return {
      videoRef,
    };
  },
  data() {
    const num = "C10011";
    const sta = "工作中";
    const his = "2022-04-10";
    return {
      num,
      sta,
      his,
    };
  },
};
</script>

<style lang="less">
.biomenu {
  width: 100%;
  height: 90%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 94%;
    padding: 2% 5% 5% 5%;
    margin-top: 10%;
    margin-left: 5%;
    margin-bottom: 3%;
    color: rgba(255, 255, 255, 0.9);
    font-family: 'Microsoft YaHei';
    font-size: 36px;
    line-height: 52px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
}
</style>
