<template>
  <div class="home_sta">
    <span
      style="
        position: absolute;
        font-size: 0.09rem;
        margin-top: 0.07rem;
        margin-left: 0.3rem;
      "
      >入侵物种</span
    >
    <img
      src="../../../../assets/back_home0.png"
      alt=""
      @click="doHome"
      style="
        width: 0.4rem;
        position: absolute;
        right: 27.5%;
        margin-top: 0.18rem;
        cursor: pointer;
        z-index: 9;
      "
    />
    <div class="map_sta" id="invade"></div>
    <div class="menu_sta"><invadeMenu /></div>
    <router-view></router-view>
  </div>
  <div>
    <el-dialog v-model="dialogVisible" title="物种详情" :show-close="false">
      <div class="btn_exit">
        <img
          src="../../../../assets/shutdown.png"
          alt=""
          @click="dialogVisible = false"
          style="
            width: 0.13rem;
            float: right;
            margin-top: -0.23rem;
            cursor: pointer;
          "
        />
      </div>
      <div>
        <div style="margin-top: 0.03rem; text-align: center">
          <p id="Group_name" style="font-fanily: 'FZMWFont'">中文名：{{ introName }}</p>
        </div>
        <img
          :src= "geturl(img)"
          alt=""
          style="width: 4.9rem; margin-top: 0"
        />
      </div>
      <template #footer>
        <span class="dialog-footer">
          {{ introduction }}                
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import * as echarts from "echarts";
import URL from '@/api/baseUrl'
import { ref } from "vue";
import { useRouter } from "vue-router";
import JIANGSU from "../../../../../public/jiangsu.json";
import invadeMenu from "./invadeMenu.vue";

export default {
  components: {
    invadeMenu,
  },
  setup() {
    const router = useRouter();
    const doHome = () => {
      console.log("doHome");
      router.push("/bio");
    };
    return {
      doHome,
    };
  },
  data() {
    const dialogVisible = ref(false);
    const point = [];
    var introName,introPicture,introduction;
    return {
      dialogVisible,
      point,
      introName,
      introPicture,
      introduction,
    };
  },
  created() {
    this.query_data();
  },
  // mounted() {
    // this.createMap();
  // },

  methods: {
    query_data: function () {
      this.$http.get(`${URL}`+`/bio/name`).then((res) => {
        var a = JSON.stringify(res.data.bioPoint.invadePoint);
        this.point = JSON.parse(a);
        this.introPicture = res.data.bioIntroduction.picname;
        this.introduction = res.data.bioIntroduction.introduction;
        this.createMap();
      });
    },
    geturl(img){
      return require("@/common/picture/"+this.introPicture+".jpg");
    },
    nav_open(params) {
      this.introName = params.name;
      this.dialogVisible = true;
      return this.introName
    },
    createMap() {
      var myChart = echarts.init(document.getElementById("invade")); // 拿到一个实例
      echarts.registerMap("江苏省", JIANGSU, {}); //引入地图文件
      // console.log(JSON);
      var option = {
        geo: {
          show: false,
          map: "江苏省",
          label: {
            show: false,
          },
          roam: false,
          itemStyle: {
            normal: {
              borderWidth: 3, //设置外层边框
              borderColor: "#1A9BEF",
              shadowColor: "rgba(26, 155, 239, 0.7)",
              shadowBlur: 12,
            },
            emphasis: {
              show: false,
              // areaColor: '#01215c'
            },
          },
        },
        series: [
          {
            type: "map",
            mapType: "江苏省", //地图名称
            color: "blue",
            roam: true,
            // center: [118.46,32.02],
            // zoom: 1,
            label: {
              show: true,
              color: "white",
              fontSize: "0.08rem",
              position: "inside",
              textShadowColor: "white",
              textShadowBlur: 6,
            },
            itemStyle: {
              // color: '#FF1E1E',
              areaColor: "rgb(0, 8, 45)",
              borderColor: "#1A9BEF",
              borderWidth: 1,
              shadowColor: "rgba(26, 155, 239, 0.5)",
              shadowBlur: 6,
            },
            emphasis: {
              label: {
                show: true,
                position: "inside",
                color: "white",
                fontSize: "0.08rem",
                textShadowColor: "white",
                textShadowBlur: 6,
              },
              itemStyle: {
                areaColor: "rgb(0, 79, 131)",
              },
            },
            select: {
              label: {
                show: true,
                position: "inside",
                color: "white",
                fontSize: "0.08rem",
                textShadowColor: "white",
                textShadowBlur: 6,
              },
              itemStyle: {
                areaColor: "#145E8E",
              },
            },
            markPoint: {
              symbol: "circle",
              symbolSize: 15,
              itemStyle: {
                color: {
                  type: "radial",
                  x: 0.5,
                  y: 0.5,
                  r: 0.5,
                  colorStops: [
                    {
                      offset: 0.3,
                      color: "#bc6dff", // 0% 处的颜色
                    },
                    {
                      offset: 1,
                      color: "transparent", // 100% 处的颜色
                    },
                  ],
                  global: false, // 缺省为 false
                },
              },
              label: {
                show: true,
                color: "white",
              },
              symbolStyle: {
                color: "yellow",
              },
              emphasis: {
                label: {
                  show: true,
                },
              },
              data: this.point,
            },
          },
        ],
      };
      myChart.setOption(option);
      document.getElementById('invade').setAttribute('_echarts_instance_','');
      myChart.on("click",  (params) => {
        // console.log(params.zoom)
        if (params.componentType == "markPoint"){
          this.nav_open(params);
        }
      });
      window.addEventListener("resize", function () {
        // 自适应大小
        myChart.resize();
      });
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .el-dialog__title {
  color: black;
  font-size: 0.1rem;
  opacity: 0.7;
  font-weight: 600;
  font-family: "Microsoft YaHei";
  margin-top: 0.2rem;
}
/deep/ .el-dialog__header {
  padding-top: 0.05rem;
  background-color: #ababab;
  border-radius: 0.03rem 0.03rem 0 0;
  height: 0.1rem;
}
/deep/ .el-dialog__body {
  background: #ffffff;
  font-size: 0.1rem;
  height: 2.1rem;
}
/deep/ .el-dialog__footer {
  padding-top: 0.06rem;
  font-size: 0.08rem;
  line-height: 0.08rem;
  color: black;
  background: #ffffff;
  border-radius: 0 0 0.01rem 0.01rem;
}
.router-link-active {
  text-decoration: none;
}
.home_sta {
  margin-top: 1%;
  height: 100%;
  width: 100%;
}
.map_sta {
  float: left;
  margin-right: 2%;
  height: 1500px;
  width: 1900px;
  background: url("../../../../assets/hdbj.png") no-repeat;
  background-size: 100% 100%;
}
.menu_sta {
  float: left;
  width: 30%;
  height: 1500px;
  background: url("../../../../assets/hdbjr.png") no-repeat;
  background-size: 100% 100%;
}
</style>
