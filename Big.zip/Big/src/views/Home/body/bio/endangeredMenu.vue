<template>
  <div class="endangeredmenu">
    <div class="title">濒危物种：</div>
    <div class="text">
      <p>
        濒危动物是指所有由于物种自身的原因或受到人类活动或自然灾害的影响，而有灭绝危险的野生动物物种。地球上的生物多样性正在高速下降，许多物种面临着灭绝的威胁。威胁野生动植物生存的主要因素是栖息地丧失、商业开发以及野生动植物及其产品的国际贸易。资源十分有限，我们必须有的放矢地针对物种的濒危等级提出具体的保护措施。我们可以根据物种濒危程度制定相应的法律，通过建立自然保护区、濒危物种繁育中心等保护生物学手段，对濒危物种实施就地保护和易地保护。同时，必须限制濒危野生动植物的国际贸易，并制定法律保护濒危物种。
      </p>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import VideoPlayer from "../VideoPlayer.vue";
import "video.js/dist/video-js.css";

export default {
  components: {
    VideoPlayer,
  },
  setup() {
    const videoRef = ref(null);
    return {
      videoRef,
    };
  },
  data() {
    const num = "C10011";
    const sta = "工作中";
    const his = "2022-04-10";
    return {
      num,
      sta,
      his,
    };
  },
};
</script>

<style lang="less">
.endangeredmenu {
  width: 100%;
  height: 90%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 94%;
    padding: 2% 5% 5% 5%;
    margin-top: 10%;
    margin-left: 5%;
    margin-bottom: 3%;
    color: rgba(255, 255, 255, 0.9);
    font-family: 'Microsoft YaHei';
    font-size: 36px;
    line-height: 52px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
}
</style>
