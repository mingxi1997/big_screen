<template>
  <div class="invademenu">
    <div class="title">物种分布：</div>
    <div class="text">
      <p>
        自然界中的物种总是处在不断迁移、扩散的动态中。而人类活动的频繁又进一步加剧了物种的扩散，使得许多生物得以突破地理隔绝，拓展至其他环境当中。对于此类原来在当地没有自然分布，因为迁移扩散、人为活动等因素出现在其自然分布范围之外的物种，统称为外来种。在外来种中，一部分物种是因为其用途，被人类有意地将其从一个地方引进到另外一个地方，这些物种被称为引入种，如加州蜜李、美国樱桃、野生大豆等。这些物种大多需要在人为照管下才能生存，对环境并没有危害。
      </p>
      <p>
        然而，在外来种（包括引入种）中，也有一些在移入后逸散到环境中成为野生状态。若新环境没有天敌的控制，加上旺盛的繁殖力和强大的竞争力，外来种就会变成入侵者，排挤环境中的原生种，破坏当地生态平衡，甚至造成对人类经济的危害性影响。此类外来种则通称为入侵种，如红火蚁、福寿螺、布袋莲、非洲大蜗牛、巴西红耳龟、松材线虫等。
      </p>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import VideoPlayer from "../VideoPlayer.vue";
import "video.js/dist/video-js.css";

export default {
  components: {
    VideoPlayer,
  },
  setup() {
    const videoRef = ref(null);
    return {
      videoRef,
    };
  },
  data() {
    const num = "C10011";
    const sta = "工作中";
    const his = "2022-04-10";
    return {
      num,
      sta,
      his,
    };
  },
};
</script>

<style lang="less">
.invademenu {
  width: 100%;
  height: 90%;
  align-content: center;
  // background: yellow;
  .title,
  .title_down {
    padding-left: 6%;
    height: 1px;
    line-height: 68px;
    margin-top: 3%;
    position: relative;
    font-size: 34px;
    font-weight: bold;
    font-style: italic;
  }
  .title {
    margin-top: 0;
    margin-bottom: 8%;
  }
  .text {
    width: 80%;
    height: 94%;
    padding: 2% 5% 5% 5%;
    margin-top: 10%;
    margin-left: 5%;
    margin-bottom: 3%;
    color: rgba(255, 255, 255, 0.9);
    font-family: 'Microsoft YaHei';
    font-size: 36px;
    line-height: 52px;
    border: 2px solid #ffb54c;
    border-radius: 0.06rem;
  }
}
</style>
