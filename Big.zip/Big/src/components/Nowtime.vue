<template>
  <div class="date-box">
    <div>{{nowTime}}</div>
  </div>
</template>

<script>
import { ref, onMounted, onBeforeUnmount } from 'vue'
export default {
  name: 'Nowtime',
  setup (props, context) {
    const nowTime = ref('')
    const nowTime2 = ref('')
    const setTime = ref(0)

    // 显示当前时间（年月日时分秒）
    function timeFormate (timeStamp) {
      const year = new Date(timeStamp).getFullYear()
      const month = new Date(timeStamp).getMonth() + 1 < 10 ? '0' + (new Date(timeStamp).getMonth() + 1) : new Date(timeStamp).getMonth() + 1
      const date = new Date(timeStamp).getDate() < 10 ? '0' + new Date(timeStamp).getDate() : new Date(timeStamp).getDate()
      const hh = new Date(timeStamp).getHours() < 10 ? '0' + new Date(timeStamp).getHours() : new Date(timeStamp).getHours()
      const mm = new Date(timeStamp).getMinutes() < 10 ? '0' + new Date(timeStamp).getMinutes() : new Date(timeStamp).getMinutes()
      nowTime.value = year + '/' + month + '/' + date + ' ' + ' ' + hh + ':' + mm
    }

    function nowTimes () {
      timeFormate(new Date())
      setTime.value && clearInterval(setTime.value)
      setTime.value = setTimeout(nowTimes, 1000)
    }

    onMounted(() => {
      nowTimes()
    })
    onBeforeUnmount(() => {
      setTime.value && clearInterval(setTime.value)
    })

    return { nowTime, nowTime2 }
  }
}
</script>

<style lang="less" scoped>
.date-box {
  display: inline-block;
  height: 100%;
}
</style>
