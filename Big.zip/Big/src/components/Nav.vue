<template>
  <div class="navbox">
    <div class="left">
      <div class="startbg"></div>
      <div class="text">欢迎您,管理员</div>
      <div class="dianBox">
        <div class="dian" :class="{'dian-active': dianActive === 1}"></div>
        <div class="dian" :class="{'dian-active': dianActive === 2}"></div>
        <div class="dian" :class="{'dian-active': dianActive === 3}"></div>
        <div class="dian" :class="{'dian-active': dianActive === 4}"></div>
      </div>
    </div>
    <div class="content" :class="{'content1':title !== '/substation'}">{{title === '/substation' ?  '江苏生物多样性观测网络南京沿江湿地站' : '江苏省生物多样性智慧管理系统'}}</div>
<!--    <div class="content">江苏省生物多样性智慧管理系统</div>-->
    <div class="right">
      <div class="text"><Nowtime /></div>
      <div class="startbg" @click="toDo"></div>
      <div class="dianBox">
        <div class="dian" :class="{'dian-active': dianActive === 4}"></div>
        <div class="dian" :class="{'dian-active': dianActive === 3}"></div>
        <div class="dian" :class="{'dian-active': dianActive === 2}"></div>
        <div class="dian" :class="{'dian-active': dianActive === 1}"></div>
      </div>
    </div>
  </div>
</template>

<script>
import Nowtime from './Nowtime'
import { useRouter, useRoute } from 'vue-router'
import {computed, ref, watch} from 'vue'
export default {
  name: 'Nav',
  components: {
    Nowtime
  },
  setup (props) {
    const router = useRouter()
    const route = useRoute()
    const title = ref('')
    const dianActive = ref(1)
    const doDian = () => {
      setTimeout(() => {
        if (dianActive.value <= 3) {
          dianActive.value++
        } else {
          dianActive.value = 1
        }
        doDian()
      }, 1000)
    }
    doDian()
    watch(() => route.fullPath, (n) => {
      title.value = n
    }, { immediate: true })
    const toDo = () => {
      if (window.history.state.current === '/') {
        router.push('/substation')
      } else {
        router.push('/')
      }
    }
    return { toDo, title, dianActive }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.navbox {
  margin: 0 50px;
  padding-top: 65px;
  width: 3696px;
  height: 109px;
  color: #ffffff;
  position: relative;
  .left {
    padding-top: 70px;
    box-sizing: border-box;
    position: absolute;
    left: 0;
    top: 0;
    width: 1177px;
    height: 100%;
    background: url('../assets/left-title-top.png') no-repeat;
    background-position: bottom;
    background-size: 100%;
    .dianBox {
      position: absolute;
      bottom: 15px;
      left: 500px;
      width: 250px;
      height: 48px;
      display: flex;
      justify-content: center;
      align-items: center;
      .dian {
        width: 48px;
        height: 48px;
        background: url('../assets/kongxin.png') no-repeat;
        background-size: 100% 100%;
      }
      .dian-active {
        background: url('../assets/shi.png') no-repeat;
        background-size: 100% 100%;
      }
    }
    .startbg {
      width: 80px;
      height: 80px;
      background: url('../assets/start.png') no-repeat;
      background-size: 100% 100%;
      display: inline-block;
      vertical-align: top;
      margin-left: 87px;
    }
    .text {
      vertical-align: top;
      display: inline-block;
      height: 80px;
      line-height: 80px;
      font-size: 33px;
      font-family: Microsoft YaHei;
      font-weight: 400;
    }
  }
  .content {
    text-align: center;
    height: 100%;
    line-height: 109px;
    width: 100%;
    font-size: 70px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    background: linear-gradient(0deg, #B7F1FD 0%, #FFFFFF 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  .content1 {
    font-size: 86px;
  }
  .right {
    padding-top: 70px;
    box-sizing: border-box;
    position: absolute;
    right: 0;
    top: 0;
    width: 1177px;
    height: 100%;
    background: url('../assets/right-title-top.png') no-repeat;
    background-position: bottom;
    background-size: 100%;
    .startbg {
      float: right;
      width: 80px;
      height: 80px;
      background: url('../assets/time.png') no-repeat;
      background-size: 100% 100%;
      display: inline-block;
      vertical-align: top;
      div {
        display: inline-block;
        vertical-align: top;
        width: 48px;
        height: 48px;
        background: #01FFFD;
      }
    }
    .text {
      float: right;
      vertical-align: top;
      display: inline-block;
      height: 80px;
      line-height: 80px;
      font-size: 33px;
      font-family: Microsoft YaHei;
      font-weight: 400;
      margin-right: 65px;
    }
    .dianBox {
      position: absolute;
      bottom: 15px;
      right: 500px;
      width: 250px;
      height: 48px;
      display: flex;
      justify-content: center;
      align-items: center;
      .dian {
        width: 48px;
        height: 48px;
        background: url('../assets/kongxin.png') no-repeat;
        background-size: 100% 100%;
      }
      .dian-active {
        background: url('../assets/shi.png') no-repeat;
        background-size: 100% 100%;
      }
    }
  }
}
</style>
