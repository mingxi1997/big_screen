import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Axios from 'axios'
// rem 自适应插件
import 'amfe-flexible'

// 饿了么
import element from './element.js'
import 'element-plus/dist/index.css'

import './common/font/font.css'
// import './assets/css/_setcss.css'
import './common/css/index.less'



import Video from 'video.js'
import 'video.js/dist/video-js.css'
const app = createApp(App)
app.use(store).use(router).mount('#app')
element(app)
app.config.globalProperties.$http = Axios
app.config.globalProperties.$video = Video //引入Video播放器


