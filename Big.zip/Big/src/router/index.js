import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../views/Home/Home.vue'
import Substation from '../views/Substation/Substation.vue'
import total from '../views/Home/body/total.vue'
import eqi from '../views/Home/body/eqi.vue'
import bio from '../views/Home/body/bio/bio.vue'
import ques from '../views/Home/body/ques.vue'
import infrared from '../views/Home/body/equip/infrared.vue'
import weather from '../views/Home/body/equip/weather.vue'
import ai from '../views/Home/body/equip/ai.vue'
import tower from '../views/Home/body/equip/tower.vue'
import jiang from '../views/Home/body/total/jiang.vue'
import he from '../views/Home/body/total/he.vue'
import hai from '../views/Home/body/total/hai.vue'
import sen from '../views/Home/body/total/sen.vue'
import endangered from '../views/Home/body/bio/endangered.vue'
import invade from '../views/Home/body/bio/invade.vue'
import invest from '../views/Home/body/bio/invest.vue'
import infraredpart from '../views/Home/body/menu/MenuInfrared.vue'
import infraredmain from '../views/Home/body/main/infraredMain.vue'
import aipart from '../views/Home/body/menu/MenuAi.vue'
import aimain from '../views/Home/body/main/aiMain.vue'
import weatherpart from '../views/Home/body/menu/MenuWeather.vue'
import weathermain from '../views/Home/body/main/weatherMain.vue'
import towerpart from '../views/Home/body/menu/MenuTower.vue'
import towermain from '../views/Home/body/main/towerMain.vue'
import questionpart from '../views/Home/body/menu/MenuQues.vue'
import questionmain from '../views/Home/body/main/quesMain.vue'

const routes = [
  {
    path: '/',
    // path: '/home',
    name: 'Home',
    component: Home,
    redirect: '/total',
    children: [
      {
        path: '/total',
        name: 'total',
        component: total,
      },
      {
        path: '/eqi',
        name: 'eqi',
        component: eqi,
      },
      {
        path: '/bio',
        name: 'bio',
        component: bio,
      },
      {
        path: '/ques',
        name: 'ques',
        component: ques,
        children: [
          {
            path: '/quesmain',
            name: 'quesmain',
            component: questionmain,
          },
          {
            path: '/quespart/:name',
            name: 'quespart',
            component: questionpart,
          }
        ]
      },
      {
        path: '/infrared',
        name: 'infrared',
        component: infrared,
        children: [
          {
            path: '/infraredmain',
            name: 'infraredmain',
            component: infraredmain,
          },
          {
            path: '/infraredpart/:name',
            name: 'infraredpart',
            component: infraredpart,
          }
        ]
      },
      {
        path: '/weather',
        name: 'weather',
        component: weather,
        children: [
          {
            path: '/weathermain',
            name: 'weathermain',
            component: weathermain,
          },
          {
            path: '/weatherpart/:name',
            name: 'weatherpart',
            component: weatherpart,
          }
        ]
      },
      {
        path: '/ai',
        name: 'ai',
        component: ai,
        children: [
          {
            path: '/aimain',
            name: 'aimain',
            component: aimain,
          },
          {
            path: '/aipart/:name',
            name: 'aipart',
            component: aipart,
          }
        ]
      },
      {
        path: '/tower',
        name: 'tower',
        component: tower,
        children: [
          {
            path: '/towermain',
            name: 'towermain',
            component: towermain,
          },
          {
            path: '/towerpart/:name',
            name: 'towerpart',
            component: towerpart,
          }
        ]
      },
      {
        path: '/jiang',
        name: 'jiang',
        component: jiang,
      },
      {
        path: '/he',
        name: 'he',
        component: he,
      },
      {
        path: '/hai',
        name: 'hai',
        component: hai,
      },
      {
        path: '/sen',
        name: 'sen',
        component: sen,
      },
      {
        path: '/endangered',
        name: 'endangered',
        component: endangered,
      },
      {
        path: '/invade',
        name: 'invade',
        component: invade,
      },
      {
        path: '/invest',
        name: 'invest',
        component: invest,
      },
    ]
  },
  {
    path: '/substation',
    // path: '/home',
    name: 'Substation',
    component: Substation
  },
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})

export default router
