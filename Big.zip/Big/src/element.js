import { ElTable, ElTooltip, ElNotification, ElProgress, ElButton ,ElIcon} from 'element-plus'

export default app => {
  app.use(ElProgress)
  app.use(ElButton)
  app.use(ElTable)
  app.use(ElTooltip)
  app.use(ElNotification)
  app.use(ElIcon)
}
