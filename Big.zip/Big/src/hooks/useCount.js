import { computed } from 'vue'
export default function (endVal) {
  const plusOne = computed(() => {
    if (endVal.value >= 100000) {
      if (endVal.value >= 999950000) {
        return 9999
      } else {
        return endVal.value / 100000
      }
    } else {
      return endVal.value
    }
  })
  const iswan = computed(() => {
    if (endVal.value >= 100000) {
      return true
    } else {
      return false
    }
  })
  return { plusOne, iswan }
}
