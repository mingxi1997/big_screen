import { reactive, ref, nextTick } from 'vue-demi'
export default function () {
  const _data = reactive({})
  const canvasWidth = ref(100)
  const step = (6 / 180) * Math.PI * 2
  // 开始角度
  let b = Math.PI * 2; let e = step / 2
  // 初始化设置颜色,设置角度
  function _initCanvas () {
    _data.ctx.beginPath()
    // 保存 后期清楚的时候用
    _data.ctx.save()
    // 将圆点移动到中心店 以便后面旋转
    _data.ctx.translate(_data.height, _data.height)
    // 从圆心旋转 -90° 上方变成0°
    _data.ctx.rotate((Math.PI / 180) * -90)
    // 每一步的大小
    createdotted()
  }
  // 画圆
  function createCicle () {
    // 递归调用 制作动画
    if (b >= _data.currentPercent) {
      _data.ctx.arc(0, 0, _data.radius, b, b - e, true)
      _data.ctx.stroke()
      b -= e
      setTimeout(() => {
        createCicle(_data.ctx)
      }, 10)
    }
  }
  function createdotted () {
    b = Math.PI * 2
    e = (1 / 180) * Math.PI * 2
    _data.ctx.lineWidth = _data.width1
    _data.ctx.beginPath()
    // 填充颜色
    _data.ctx.strokeStyle = '#3F2B4C'
    _data.ctx.arc(0, 0, _data.radius1, b, (b + 0.001), true)
    _data.ctx.stroke()
    _data.ctx.beginPath()
    // 结束之后 制作字体
    _data.ctx.rotate((Math.PI / 180) * 90)
    // 设置字体
    _data.ctx.font = `normal bold ${25 * _data.ratio
              }px Microsoft YaHei, Microsoft YaHei-Bold`
    // 设置颜色
    _data.ctx.fillStyle = '#32B0F9'
    // 设置水平对齐方式
    _data.ctx.textAlign = 'center'
    // 设置垂直对齐方式
    _data.ctx.textBaseline = 'top'
    // 绘制文字（参数：要写的字，x坐标，y坐标）
    _data.ctx.fillText(_data.percent * 100 + '%', 0, 5)
    // 设置垂直对齐方式
    _data.ctx.textBaseline = 'bottom'
    _data.ctx.font = `normal ${14 * _data.ratio
    }px Microsoft YaHei, Microsoft YaHei-Bold`
    // 设置颜色
    _data.ctx.fillStyle = '#fff'
    _data.ctx.lineWidth = _data.width
    // 绘制文字（参数：要写的字，x坐标，y坐标）
    _data.ctx.fillText(_data.gender, 0, -5)
    _data.ctx.rotate((Math.PI / 180) * -90)
    _data.ctx.lineCap = 'round'
    // 填充颜色
    const g = _data.ctx.createLinearGradient(0, 0, 0, 50)
    g.addColorStop(0, _data.color1)
    g.addColorStop(1, _data.color2)
    _data.ctx.strokeStyle = g
    createCicle(_data.ctx)
  }

  function initCanvas (canvas, gender, color, percent) {
    _data.percent = percent
    _data.gender = gender
    _data.color1 = color.split(',')[0]
    _data.color2 = color.split(',')[1]
    _data.currentPercent = Math.PI * 2 * (1 - _data.percent)
    _data.ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const bsr =
        _data.ctx.webkitBackingStorePixelRatio ||
        _data.ctx.mozBackingStorePixelRatio ||
        _data.ctx.msBackingStorePixelRatio ||
        _data.ctx.oBackingStorePixelRatio ||
        _data.ctx.backingStorePixelRatio ||
            1
    _data.ratio = dpr / bsr
    // 更改canvas width 根据屏幕比例调整
    canvasWidth.value = 130 * _data.ratio
    _data.height = (canvas.clientHeight / 2) * _data.ratio
    // 线宽度
    _data.width = 5 * _data.ratio
    _data.width1 = 10 * _data.ratio
    // 半径 需要减掉线宽 不然会超出
    _data.radius = _data.height - _data.width
    _data.radius1 = _data.height - _data.width1 + 5
    nextTick(() => {
      _initCanvas()
    })
  }

  function reDrawn (percent) {
    _data.percent = percent
    _data.currentPercent = Math.PI * 2 * (1 - _data.percent)
    _data.ctx.restore()
    _data.ctx.clearRect(0, 0, _data.height * 2, _data.height * 2)
    nextTick(() => {
      _initCanvas()
    })
  }
  return {
    canvasWidth,
    initCanvas,
    reDrawn
  }
}
