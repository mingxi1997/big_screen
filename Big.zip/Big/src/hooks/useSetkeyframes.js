/**
 * @param keyframesname // keyframes 的名字
 * @param length // 遍历的单个
 * @param height
 *  */
export default function (keyframesname, length, height) {
  // 获取所有的style样式
  // 寻找ball keyframes对应的style样式
  // 获取方式：根据animation运动的名称ball-run查询到对应的keyframes对应的style
  // const animation = {}
  const ss = document.styleSheets
  // function getkeyframes (name) {
  //   // 获取所有的style
  //   for (let i = 0; i < ss.length; ++i) {
  //     const item = ss[i]
  //     if (item.cssRules[0] && item.cssRules[0].name && item.cssRules[0].name === name) {
  //       animation.cssRule = item.cssRules[0]
  //       animation.styleSheet = ss[i]
  //       animation.index = 0
  //     }
  //   }
  //   return animation
  // }

  // const ballRunKeyframes = getkeyframes(keyframesname)
  // console.log(ballRunKeyframes)
  // deleteRule方法用来从当前样式表对象中删除指定的样式规则
  // ballRunKeyframes.styleSheet.deleteRule(99999999999999)
  // console.log(13)
  // 重新定义ball从定位在(20,30)的位置运动到(400,500) 的位置
  const runkeyframes = ` @keyframes ${keyframesname} {
    0%{
      transform: translate3d(0, 0, 0);
    }
    100%{
      transform: translate3d(0, -${length * height}px, 0);
    }
  }`
  // insertRule方法用来给当前样式表插入新的样式规则.
  // ballRunKeyframes.styleSheet.insertRule(runkeyframes, 99999999999999)
  ss[0].insertRule(runkeyframes, 0)
  // 此时已经修改好了ball-run 对应的keyframes了，但是在坑爹的IE中小球ball依然没有改变为他的运动方式，解决方案就是，从新刷新ball Dom中的animation的值
}
