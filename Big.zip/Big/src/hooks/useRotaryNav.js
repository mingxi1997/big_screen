import { onMounted, ref, onBeforeUnmount } from 'vue'
export default function (divnodes, oWrap, renbox) {
  const _time = ref(null)
  // 1.获取元素
  const oImg = divnodes
  // const oImgLen=oImg.length;
  let deg = 360 / oImg.length// 3.每个需要旋转的度数
  // 定义一个开始的度数
  const roX = -5
  let roY = 0
  // let x; let y; let x_; let y_; let xN; let yN; let time = null
  function mycleartime () {
    _time.value && clearInterval(_time.value)
  }
  function myfoundtime () {
    _time.value && clearInterval(_time.value)
    _time.value = setInterval(titme, 20)
    function titme () {
      roY += 1 * 0.2// 水平拖影响Y轴;
      oWrap.value.style.transform = 'translate(-50%, 0) perspective(600px) rotateX(-5deg) rotateY(' + roY + 'deg)'
      renbox.value.style.transform = 'translate(-50%, 0) rotateY(' + -roY + 'deg)'
    }
  }
  onMounted(() => {
    // const oImgLen=oImg.length;
    deg = 360 / oImg.length// 3.每个需要旋转的度数
    // 2.遍历所有的img标签
    for (let i = 0; i < oImg.length; i++) {
    // oImg[i].style.cssText='transform:rotateY('+i*deg+'deg ) translateZ(350px);transition:1s'+ (oImgLen-i)*0.1 +'s;';
      oImg[i].style.transform = 'translate(-50%, 0) rotateY(' + i * deg + 'deg) translateZ(300px) rotateX(' + -roX + 'deg)'
      oImg[i].style.transition = 'all 1s ' + (oImg.length - i - 1) * 0.1 + 's'
      // transition:设置过渡
      oImg[i].ondragstart = function () {
        return false
      }
    }
    myfoundtime()
  })
  onBeforeUnmount(() => {
    mycleartime()
  })
  return { mycleartime, myfoundtime }
}
